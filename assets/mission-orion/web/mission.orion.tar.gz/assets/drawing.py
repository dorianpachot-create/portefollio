"""
drawing.py — Primitives de dessin UI (cadres, boutons, arsenal, popup O.R.I.O.N.)

Tout suit le style "portfolio Gradient" : pas de border-radius, bordures pleines
3px, ombres dures sans flou, palette jaune / cyan / espace profond.
"""

import math
import pygame

import state
from config import (
    SPACE_1, PANEL_BG, PANEL_BG_ALPHA, PANEL_BORDER, SHADOW_OFFSET,
    ACCENT, ACCENT_CYAN, TEXT_MAIN, TEXT_MUTED,
    ROBOT_GREY, ROBOT_DETAIL, ASSISTANT_EYE_COLORS,
)


# ── Texte multi-lignes ────────────────────────────────────────────────────────

def draw_text_simple(surface, text, color, x, y, font_obj):
    lh = font_obj.get_linesize()
    for i, line in enumerate(text.split('\n')):
        ts = font_obj.render(line, True, color)
        surface.blit(ts, (x, y + i * lh))


# ── Cadre pixel (style portfolio : 3px solide, ombre dure, pas d'arrondi) ─────

def dessiner_cadre_pixel(surface, rect, border_color=None, bg_alpha=None, shadow=True):
    """Reproduit le `.section__panel` du portfolio : fond sombre semi-opaque,
       bordure pleine 3px, ombre dure décalée."""
    if border_color is None:
        border_color = PANEL_BORDER
    if bg_alpha is None:
        bg_alpha = PANEL_BG_ALPHA

    if shadow:
        sh = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        sh.fill((0, 0, 0, 115))
        surface.blit(sh, (rect.x + SHADOW_OFFSET, rect.y + SHADOW_OFFSET))

    bg = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    bg.fill((*PANEL_BG, bg_alpha))
    surface.blit(bg, rect.topleft)
    pygame.draw.rect(surface, border_color, rect, 3)


# ── Bouton (style menu de jeu rétro du portfolio) ─────────────────────────────

def dessiner_bouton_verre(surface, rect, texte, police, couleur_texte=None, disabled=False):
    """Bouton rétro : bordure 3px jaune, fond sombre. Hover = remplissage, clic = offset."""
    accent_col = couleur_texte if couleur_texte is not None else ACCENT
    mx, my = pygame.mouse.get_pos()
    hovered = rect.collidepoint(mx, my) and not disabled
    clic    = pygame.mouse.get_pressed()[0] and hovered

    # Ombre dure
    sh = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    sh.fill((0, 0, 0, 115))
    off = 2 if clic else SHADOW_OFFSET
    surface.blit(sh, (rect.x + off, rect.y + off))

    draw_rect = rect.move(2, 2) if clic else rect.copy()

    if disabled:
        border_col, txt_col = PANEL_BORDER, TEXT_MUTED
        bg_s = pygame.Surface((draw_rect.width, draw_rect.height), pygame.SRCALPHA)
        bg_s.fill((*PANEL_BG, 180)); surface.blit(bg_s, draw_rect.topleft)
    elif hovered:
        pygame.draw.rect(surface, accent_col, draw_rect)
        border_col, txt_col = accent_col, SPACE_1
    else:
        bg_s = pygame.Surface((draw_rect.width, draw_rect.height), pygame.SRCALPHA)
        bg_s.fill((*PANEL_BG, 180)); surface.blit(bg_s, draw_rect.topleft)
        border_col, txt_col = accent_col, accent_col

    pygame.draw.rect(surface, border_col, draw_rect, 3)
    txt_s = police.render(texte, True, txt_col)
    surface.blit(txt_s, txt_s.get_rect(center=draw_rect.center))


# ── O.R.I.O.N. (icône procédurale) ────────────────────────────────────────────

def dessiner_orion_procedurale(surface, cx, cy, scale=1.0):
    bs  = int(35 * scale)
    eye = ASSISTANT_EYE_COLORS[0]
    pygame.draw.circle(surface, ROBOT_GREY, (cx, cy), bs)
    pygame.draw.circle(surface, ROBOT_DETAIL, (cx, cy), bs, 2)
    ah = int(15 * scale)
    pygame.draw.line(surface, ROBOT_DETAIL, (cx, cy-bs), (cx, cy-bs-ah), 3)
    pygame.draw.circle(surface, eye, (cx, cy-bs-ah), int(4*scale))
    eo = int(12 * scale); es = int(6 * scale)
    pygame.draw.circle(surface, eye, (cx-eo, cy-int(5*scale)), es)
    pygame.draw.circle(surface, eye, (cx+eo, cy-int(5*scale)), es)
    my2 = cy + int(8*scale); mw = int(16*scale)
    pygame.draw.line(surface, ROBOT_DETAIL, (cx-mw, my2), (cx+mw, my2), 2)
    for angle_deg in (0, 120, 240):
        rad = math.radians(angle_deg)
        px = cx + int(math.cos(rad) * bs * 0.7)
        py = cy + int(math.sin(rad) * bs * 0.7)
        pygame.draw.circle(surface, eye, (px, py), 2)


# ── Arsenal compact (rappel dans un coin) ─────────────────────────────────────

def dessiner_arsenal(surface, rect, inventory, selected_index):
    """4 cases côte à côte avec icônes de bonus, style cadre pixel."""
    dessiner_cadre_pixel(surface, rect, border_color=PANEL_BORDER)

    # Titre
    titre = state.font_bold.render(f"ARSENAL  {len(inventory)}/4", True, ACCENT)
    surface.blit(titre, (rect.x + 10, rect.y + 6))

    # Cases inventaire
    pad     = max(4, rect.width // 60)
    titre_h = titre.get_height() + 6
    inner_h = rect.height - titre_h - pad
    case_sz = min(inner_h, (rect.width - pad * 5) // 4)
    cy      = rect.y + titre_h + (inner_h - case_sz) // 2
    total_w = case_sz * 4 + pad * 3
    cx0     = rect.x + (rect.width - total_w) // 2

    ICONS = {
        "bombe": state.bonus_img,
        "vie":   state.vie_img,
        "laser": state.bonus_laser_img,
    }

    for i in range(4):
        cx = cx0 + i * (case_sz + pad)
        case_rect = pygame.Rect(cx, cy, case_sz, case_sz)
        est_selectionne = i == selected_index and i < len(inventory)

        bg = pygame.Surface((case_sz, case_sz), pygame.SRCALPHA)
        bg.fill((*SPACE_1, 200))
        surface.blit(bg, case_rect.topleft)
        pygame.draw.rect(surface, ACCENT if est_selectionne else PANEL_BORDER,
                         case_rect, 2)

        if i < len(inventory):
            src = ICONS.get(inventory[i])
            if src is not None:
                ic_size = max(8, case_sz - 12)
                img = pygame.transform.scale(src, (ic_size, ic_size))
                surface.blit(img, img.get_rect(center=case_rect.center))


# ── Popup assistant (bas gauche, non bloquant, style portfolio) ───────────────

def dessiner_popup_assistant_corner(surface, rect, message):
    """Petit cadre style `.section__panel` avec l'avatar d'O.R.I.O.N. + le texte."""
    dessiner_cadre_pixel(surface, rect, border_color=ACCENT_CYAN)

    # Chip "// O.R.I.O.N." attaché au coin haut-gauche
    label_w = state.font_item.size("// O.R.I.O.N.")[0] + 16
    label_h = state.font_item.get_linesize() + 6
    label_bg = pygame.Rect(rect.x, rect.y - label_h, label_w, label_h)
    pygame.draw.rect(surface, ACCENT_CYAN, label_bg)
    tag = state.font_item.render("// O.R.I.O.N.", True, SPACE_1)
    surface.blit(tag, (label_bg.x + 8, label_bg.y + 2))

    # Avatar à gauche
    avatar_size = min(rect.height - 16, int(rect.width * 0.22))
    avatar_cx   = rect.x + 12 + avatar_size // 2
    avatar_cy   = rect.centery
    dessiner_orion_procedurale(surface, avatar_cx, avatar_cy, avatar_size / 80.0)

    # Texte (VT323 lisible)
    fnt    = state.font
    lines  = message.split('\n')
    line_h = fnt.get_linesize()
    text_h = line_h * len(lines)
    tx = rect.x + 24 + avatar_size
    ty = rect.y + (rect.height - text_h) // 2
    for i, line in enumerate(lines):
        ts = fnt.render(line, True, TEXT_MAIN)
        surface.blit(ts, (tx, ty + i * line_h))
