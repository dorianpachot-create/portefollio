"""
procedural.py — Génération procédurale des arrière-plans (Mission Orion)
"""

import pygame
import random
import math
from config import NIVEAUX

# Cache des fonds (style, w, h) → Surface
_cache: dict = {}


# ── Primitives ────────────────────────────────────────────────────────────────

def generate_stars(rng, w, h, count):
    stars = []
    for _ in range(count):
        x  = rng.randint(0, w-1)
        y  = rng.randint(0, h-1)
        br = rng.randint(60, 255)
        sz = rng.choice([1, 1, 1, 2, 2, 3])
        ct = rng.randint(0, 4)
        if ct == 0:
            col = (br, br, min(255, br+40))
        elif ct == 1:
            col = (min(255, br+20), min(255, br+10), br)
        else:
            col = (br, br, br)
        stars.append((x, y, sz, col))
    return stars


def draw_stars_on(surface, stars):
    for x, y, size, col in stars:
        if size == 1:
            if 0 <= x < surface.get_width() and 0 <= y < surface.get_height():
                surface.set_at((x, y), col)
        elif size == 2:
            pygame.draw.circle(surface, col, (x, y), 1)
        else:
            pygame.draw.circle(surface, col, (x, y), 2)
            halo = pygame.Surface((8, 8), pygame.SRCALPHA)
            pygame.draw.circle(halo, (*col, 50), (4, 4), 3)
            surface.blit(halo, (x-4, y-4))


def draw_nebula_on(surface, rng, w, h, color, density=6):
    for _ in range(density):
        nx = rng.randint(int(w*0.05), int(w*0.95))
        ny = rng.randint(int(h*0.05), int(h*0.95))
        nr = rng.randint(int(w*0.06), int(w*0.20))
        base_alpha = rng.randint(10, 25)
        neb_s = pygame.Surface((nr*2+4, nr*2+4), pygame.SRCALPHA)
        for lr in range(5, 0, -1):
            lr_r = nr * lr // 5
            lr_a = int(base_alpha * (5-lr+1) / 5)
            pygame.draw.circle(neb_s, (*color, lr_a), (nr+2, nr+2), lr_r)
        surface.blit(neb_s, (nx-nr-2, ny-nr-2))


# ── Création d'un fond par style ──────────────────────────────────────────────

def create_procedural_background(w, h, style=0):
    surf = pygame.Surface((w, h))
    rng  = random.Random(style * 100 + 42)

    # Dégradé vertical commun
    gradients = {
        0: ((8,12,35), (18,30,65)),
        1: ((15,8,20), (35,18,35)),
        2: ((12,5,30), (27,13,55)),
        3: ((10,18,25), (22,33,45)),
        4: ((5,8,28), (13,20,50)),
        5: ((20,5,20), (40,10,35)),
        6: ((5,3,15), (15,8,30)),
        7: ((10,5,35), (25,13,60)),
    }
    top, bot = gradients.get(style, ((10,15,40), (10,15,40)))
    for y in range(h):
        r2 = y / max(h, 1)
        col = (int(top[0]+r2*(bot[0]-top[0])), int(top[1]+r2*(bot[1]-top[1])), int(top[2]+r2*(bot[2]-top[2])))
        pygame.draw.line(surf, col, (0, y), (w, y))

    if style == 0:
        draw_stars_on(surf, generate_stars(rng, w, h, 200))
        draw_nebula_on(surf, rng, w, h, (20, 40, 120), 5)

    elif style == 1:
        draw_stars_on(surf, generate_stars(rng, w, h, 150))
        draw_nebula_on(surf, rng, w, h, (80, 30, 20), 4)
        draw_nebula_on(surf, rng, w, h, (40, 20, 10), 3)
        for _ in range(8):
            rx = rng.randint(0, w); ry = rng.randint(0, h)
            rr = rng.randint(5, 18)
            col_r = (rng.randint(50,80), rng.randint(40,65), rng.randint(35,55))
            pygame.draw.circle(surf, col_r, (rx, ry), rr)
            pygame.draw.circle(surf, (30,25,20), (rx, ry), rr, 1)

    elif style == 2:
        draw_stars_on(surf, generate_stars(rng, w, h, 180))
        draw_nebula_on(surf, rng, w, h, (80, 20, 120), 5)
        draw_nebula_on(surf, rng, w, h, (30, 10, 80), 4)

    elif style == 3:
        grid_col = (25, 45, 55)
        for gx in range(0, w, 60):
            pygame.draw.line(surf, grid_col, (gx, 0), (gx, h), 1)
        for gy in range(0, h, 60):
            pygame.draw.line(surf, grid_col, (0, gy), (w, gy), 1)
        for _ in range(12):
            lx = rng.randint(0, w); ly = rng.randint(0, h)
            lc = rng.choice([(40,180,40),(180,140,40),(40,120,180)])
            pygame.draw.circle(surf, lc, (lx, ly), rng.randint(2, 5))
            glow_s = pygame.Surface((20, 20), pygame.SRCALPHA)
            pygame.draw.circle(glow_s, (*lc, 30), (10, 10), 8)
            surf.blit(glow_s, (lx-10, ly-10))

    elif style == 4:
        draw_stars_on(surf, generate_stars(rng, w, h, 220))
        draw_nebula_on(surf, rng, w, h, (10, 30, 100), 6)
        draw_nebula_on(surf, rng, w, h, (20, 60, 120), 3)

    elif style == 5:
        draw_stars_on(surf, generate_stars(rng, w, h, 160))
        draw_nebula_on(surf, rng, w, h, (100, 10, 10), 5)
        draw_nebula_on(surf, rng, w, h, (60, 5, 40), 3)

    elif style == 6:
        draw_stars_on(surf, generate_stars(rng, w, h, 100))
        draw_nebula_on(surf, rng, w, h, (60, 10, 80), 3)
        for _ in range(3):
            hx = rng.randint(int(w*0.2), int(w*0.8))
            hy = rng.randint(int(h*0.1), int(h*0.6))
            hr = rng.randint(int(w*0.12), int(w*0.25))
            hs = pygame.Surface((hr*2+4, hr*2+4), pygame.SRCALPHA)
            pygame.draw.circle(hs, (80, 10, 100, 18), (hr+2, hr+2), hr)
            surf.blit(hs, (hx-hr-2, hy-hr-2))

    elif style == 7:
        draw_stars_on(surf, generate_stars(rng, w, h, 250))
        draw_nebula_on(surf, rng, w, h, (60, 20, 120), 6)
        draw_nebula_on(surf, rng, w, h, (20, 50, 100), 4)

    else:
        draw_stars_on(surf, generate_stars(rng, w, h, 150))

    return surf


def get_fond_procedural(style: int, w: int, h: int) -> pygame.Surface:
    """Retourne un fond mis en cache (créé une seule fois par (style,w,h))."""
    key = (style, w, h)
    if key not in _cache:
        _cache[key] = create_procedural_background(w, h, style)
    return _cache[key]


def get_fond_pour_niveau(niveau_id: int, w: int, h: int) -> pygame.Surface:
    style = NIVEAUX[niveau_id]['fond_style'] if niveau_id < len(NIVEAUX) else 0
    return get_fond_procedural(style, w, h)


def clear_cache():
    """Vider le cache (appeler après un changement de résolution)."""
    _cache.clear()
