"""
assets.py — Chargement, mise à l'échelle des images, polices et sons.

Exporte trois entrées principales :
- `charger_ressources()` : chargement disque unique au démarrage.
- `update_fonts()`       : (re)construction des polices selon la résolution.
- `rescale_all_images()` : (re)mise à l'échelle des sprites selon la résolution.
- `recalculer_zones()`   : positions/tailles des zones UI (RECT_JEU, arsenal, popup).
"""

import os
import pygame

import state
from config import (
    CHEMIN_IMAGE, CHEMIN_BALLE, CHEMIN_VIE, CHEMIN_BONUS, CHEMIN_ETAGERE,
    CHEMIN_BOUCLIER, CHEMIN_ALIEN1, CHEMIN_ALIEN2, CHEMIN_ALIEN3,
    CHEMIN_ASTEROIDE, CHEMIN_BOSS, CHEMIN_MUSIQUE,
    CHEMIN_SON_TIR, CHEMIN_SON_EXPLO, CHEMIN_SON_DEGAT, CHEMIN_SON_BONUS,
    CHEMIN_FONT_PIXEL_REG, CHEMIN_FONT_PIXEL_BOLD, CHEMIN_FONT_READABLE,
    _p,
    SILVER, LASER_COLOR, RED_DANGER, GREEN_OK, YELLOW_GOLD, GREY_ROCK, CYAN_LASER,
)


# ── Helpers image ─────────────────────────────────────────────────────────────

def charger_img(chemin, taille, rotation=0, couleur_secours=(235, 245, 255)):
    """Charge une image, la redimensionne, et la rote.
    Chaque étape est isolée pour rester compatible pygbag/Pyodide (où
    convert_alpha ou rotate peuvent échouer ponctuellement sans casser tout)."""
    # 1. Load
    try:
        img = pygame.image.load(chemin)
    except Exception:
        s = pygame.Surface(taille, pygame.SRCALPHA)
        s.fill(couleur_secours)
        return s
    # 2. convert_alpha (optionnel — accélère le rendu mais peut échouer en web
    #    si la surface display n'a pas le bon format)
    try:
        img = img.convert_alpha()
    except Exception:
        pass
    # 3. Scale
    try:
        if taille and taille[0] > 0 and taille[1] > 0:
            img = pygame.transform.scale(img, taille)
    except Exception:
        pass
    # 4. Rotation (idem, isolée pour ne pas perdre l'image si elle plante)
    if rotation:
        try:
            img = pygame.transform.rotate(img, rotation)
        except Exception:
            pass
    return img


# ── Polices ───────────────────────────────────────────────────────────────────

def _load_ttf(path, size):
    try:
        return pygame.font.Font(path, max(size, 10))
    except Exception:
        return pygame.font.SysFont("Courier New", max(size, 10), bold=True)


def _get_scaled_font(base_size, bold=False, readable=False):
    """`bold=True` → Pixelify Bold (titres). `readable=True` → VT323 (lecture).
       Sinon Pixelify Regular (UI)."""
    scale = min(state.WIDTH / 1600, state.HEIGHT / 900)
    size  = int(base_size * scale)
    if readable:
        return _load_ttf(CHEMIN_FONT_READABLE, size)
    if bold:
        return _load_ttf(CHEMIN_FONT_PIXEL_BOLD, size)
    return _load_ttf(CHEMIN_FONT_PIXEL_REG, size)


def update_fonts():
    # VT323 (lecture courante, multi-lignes)
    state.font      = _get_scaled_font(28, readable=True)
    state.font_item = _get_scaled_font(22, readable=True)
    state.font_lore = _get_scaled_font(32, readable=True)
    # Pixelify Sans Bold (titres, HUD)
    state.font_bold     = _get_scaled_font(24,  bold=True)
    state.font_big      = _get_scaled_font(32,  bold=True)
    state.font_gameover = _get_scaled_font(64,  bold=True)
    state.font_huge     = _get_scaled_font(150, bold=True)
    state.font_alert    = _get_scaled_font(80,  bold=True)


# ── Sprites (redimensionnés) ──────────────────────────────────────────────────

def rescale_all_images():
    scale = min(state.WIDTH / 1600, state.HEIGHT / 900)
    state.player_size    = int(160 * scale)
    state.alien_size     = int(120 * scale)
    state.asteroide_size = int(120 * scale)
    state.bullet_size    = (int(60 * scale), int(26 * scale))
    state.vie_size       = int(50  * scale)
    state.bonus_size     = int(75  * scale)

    ps   = state.player_size
    als  = state.alien_size
    vs   = state.vie_size
    asts = state.asteroide_size
    bns  = state.bonus_size

    state.player_img           = charger_img(CHEMIN_IMAGE,     (ps, ps),  rotation=-90, couleur_secours=SILVER)
    state.alien_img_defaut     = charger_img(_p("alien.png"),  (als, als), couleur_secours=GREEN_OK)
    state.balle_img            = charger_img(CHEMIN_BALLE,     state.bullet_size, couleur_secours=LASER_COLOR)
    state.vie_img              = charger_img(CHEMIN_VIE,       (vs, vs),  couleur_secours=RED_DANGER)
    state.asteroide_img_defaut = charger_img(CHEMIN_ASTEROIDE, (asts, asts), couleur_secours=GREY_ROCK)
    state.bonus_img            = charger_img(CHEMIN_BONUS,     (bns, bns), couleur_secours=YELLOW_GOLD)
    state.bonus_laser_img      = charger_img(CHEMIN_BALLE,     (int(60*scale), int(30*scale)),
                                             couleur_secours=CYAN_LASER)

    # Variante grisée pour les vies non disponibles
    state.vie_grise_img = state.vie_img.copy()
    state.vie_grise_img.fill((40, 50, 60), special_flags=pygame.BLEND_RGB_MULT)


# ── Zones d'affichage ─────────────────────────────────────────────────────────

def recalculer_zones():
    W, H = state.WIDTH, state.HEIGHT

    # Zone de jeu plein écran
    state.RECT_JEU   = pygame.Rect(0, 0, W, H)
    state.center_jeu = (state.RECT_JEU.centerx, state.RECT_JEU.centery)

    margin = int(min(W, H) * 0.018)

    # Rappel arsenal compact en bas à droite (4 cases horizontales)
    arsenal_w = int(W * 0.30)
    arsenal_h = int(H * 0.11)
    state.RECT_ARSENAL_AREA = pygame.Rect(
        W - arsenal_w - margin,
        H - arsenal_h - margin - 20,
        arsenal_w, arsenal_h,
    )

    # Popup assistant — bas gauche, taille proportionnelle
    popup_w = int(W * 0.32)
    popup_h = int(H * 0.13)
    state.RECT_POPUP_ASSISTANT = pygame.Rect(
        margin,
        H - popup_h - margin - 20,
        popup_w, popup_h,
    )


# ── Chargement initial ────────────────────────────────────────────────────────

def charger_ressources():
    """Appelé une fois au démarrage (après pygame.init)."""
    # Étagère (décor arsenal — fallback géré côté dessin)
    try:
        state.etagere_original = pygame.image.load(CHEMIN_ETAGERE).convert_alpha()
    except Exception:
        state.etagere_original = None

    # Bouclier
    try:
        state.bouclier_img = pygame.image.load(CHEMIN_BOUCLIER).convert_alpha() \
            if os.path.exists(CHEMIN_BOUCLIER) else None
    except Exception:
        state.bouclier_img = None

    # Aliens (sources haute résolution, redimensionnées à la volée)
    for at, path in [('alien1', CHEMIN_ALIEN1), ('alien2', CHEMIN_ALIEN2), ('alien3', CHEMIN_ALIEN3)]:
        try:
            state.aliens_images[at] = pygame.image.load(path).convert_alpha()
        except Exception:
            state.aliens_images[at] = None

    # Astéroïde et Boss (sources)
    try:
        state.asteroide_img = pygame.image.load(CHEMIN_ASTEROIDE).convert_alpha()
    except Exception:
        state.asteroide_img = None
    try:
        state.boss_raw_img = pygame.image.load(CHEMIN_BOSS).convert_alpha()
    except Exception:
        state.boss_raw_img = None

    # Sons
    try:
        if os.path.exists(CHEMIN_MUSIQUE):
            pygame.mixer.music.load(CHEMIN_MUSIQUE)
        state.son_tir       = pygame.mixer.Sound(CHEMIN_SON_TIR)   if os.path.exists(CHEMIN_SON_TIR)   else None
        state.son_explosion = pygame.mixer.Sound(CHEMIN_SON_EXPLO) if os.path.exists(CHEMIN_SON_EXPLO) else None
        state.son_degat     = pygame.mixer.Sound(CHEMIN_SON_DEGAT) if os.path.exists(CHEMIN_SON_DEGAT) else None
        state.son_bonus     = pygame.mixer.Sound(CHEMIN_SON_BONUS) if os.path.exists(CHEMIN_SON_BONUS) else None
    except Exception:
        pass
