"""
entities.py — Classe Boss et fonctions de particules (Mission Orion)
"""

import random
import math
import pygame

import state
from config import (
    PURPLE_BOSS, GLOW_ENEMY_COLOR, GREY_ROCK, RED_DANGER, RED_DARK,
    TERM_GREEN, SILVER, YELLOW_GOLD, WHITE,
)


# ── Particules ────────────────────────────────────────────────────────────────

def create_explosion(x, y, color):
    for _ in range(random.randint(6, 10)):
        state.particles.append({
            'x': x, 'y': y,
            'vx': random.uniform(-4, 4), 'vy': random.uniform(-4, 4),
            'life': random.randint(20, 40),
            'size': random.randint(3, 6),
            'color': color,
        })


def create_bomb_explosion(x, y):
    colors = [
        (255, 220, 0), (255, 180, 0), (255, 255, 80),
        (255, 140, 0), (255, 255, 200),
    ]
    for _ in range(random.randint(18, 28)):
        col   = random.choice(colors)
        speed = random.uniform(3, 9)
        angle = random.uniform(0, 2 * math.pi)
        state.particles.append({
            'x': x, 'y': y,
            'vx': math.cos(angle) * speed, 'vy': math.sin(angle) * speed,
            'life': random.randint(25, 50),
            'size': random.randint(4, 9),
            'color': col,
        })
    for _ in range(random.randint(12, 18)):
        col   = (255, random.randint(180, 255), 0)
        speed = random.uniform(1, 5)
        angle = random.uniform(0, 2 * math.pi)
        state.particles.append({
            'x': x + random.uniform(-10, 10),
            'y': y + random.uniform(-10, 10),
            'vx': math.cos(angle) * speed, 'vy': math.sin(angle) * speed,
            'life': random.randint(35, 65),
            'size': random.randint(2, 4),
            'color': col,
        })


def draw_outline_glow(surface, center, radius, color=GLOW_ENEMY_COLOR, layers=3):
    cx, cy = int(center[0]), int(center[1])
    for i in range(layers, 0, -1):
        alpha = int(200 / i)
        r     = radius + i * 2
        size  = r * 2 + 8
        temp  = pygame.Surface((size, size), pygame.SRCALPHA)
        pygame.draw.circle(temp, (*color, alpha), (size//2, size//2), r, 2)
        surface.blit(temp, (cx - size//2, cy - size//2))


# ── Boss ──────────────────────────────────────────────────────────────────────

class Boss:
    def __init__(self, center_x, center_y):
        self.x            = float(center_x)
        self.y            = float(center_y - 300)
        self.size         = int(220 * min(state.WIDTH/1600, state.HEIGHT/900))
        self.vie          = 1000
        self.vie_max      = 1000
        self.phase        = 1
        self.attack_timer = 0
        self.orbit_angle  = 0.0
        self.orbit_speed  = 0.008
        self.orbit_radius = min(260, state.RECT_JEU.width // 4)
        self.in_orbit     = False
        self.entry_speed  = 3.0
        self.projectiles  = []
        self.defeated     = False
        self.rot_angle    = 0.0

    # ── Update ────────────────────────────────────────────────────────────────

    def update(self, player_pos):
        if self.defeated:
            return
        px, py = player_pos

        if not self.in_orbit:
            tx = px + math.cos(self.orbit_angle) * self.orbit_radius
            ty = py + math.sin(self.orbit_angle) * self.orbit_radius
            dx = tx - self.x; dy = ty - self.y
            dist = math.hypot(dx, dy)
            if dist < 8:
                self.in_orbit = True
            else:
                self.x += (dx/dist) * min(self.entry_speed, dist)
                self.y += (dy/dist) * min(self.entry_speed, dist)
        else:
            speed_mult = 1.0 + (self.phase - 1) * 0.35
            self.orbit_angle += self.orbit_speed * speed_mult
            self.x = px + math.cos(self.orbit_angle) * self.orbit_radius
            self.y = py + math.sin(self.orbit_angle) * self.orbit_radius
            half = self.size // 2
            self.x = max(state.RECT_JEU.left  + half, min(state.RECT_JEU.right  - half, self.x))
            self.y = max(state.RECT_JEU.top   + half, min(state.RECT_JEU.bottom - half, self.y))

            self.attack_timer += 1
            interval = {1: 130, 2: 90, 3: 60}[self.phase]
            if self.attack_timer >= interval:
                self.attack_timer = 0
                if   self.phase == 1: self._shoot_asteroid(player_pos, 1)
                elif self.phase == 2: self._shoot_asteroids_triple(player_pos)
                else:                 self._shoot_asteroids_spiral(player_pos)

        self.rot_angle += 0.5

        for proj in self.projectiles[:]:
            proj['x'] += proj['vx']
            proj['y'] += proj['vy']
            proj['rotation'] += proj['rot_speed']
            if not state.RECT_JEU.collidepoint(proj['x'], proj['y']):
                self.projectiles.remove(proj)

    # ── Tirs ──────────────────────────────────────────────────────────────────

    def _make_proj(self, vx, vy, size=28, hp=2):
        return {
            'x': float(self.x), 'y': float(self.y),
            'vx': vx, 'vy': vy, 'size': size, 'hp': hp,
            'rotation': random.randint(0, 360),
            'rot_speed': random.uniform(-4, 4),
        }

    def _shoot_asteroid(self, target, hp=2):
        dx = target[0]-self.x; dy = target[1]-self.y
        d  = math.hypot(dx, dy)
        if d > 0:
            self.projectiles.append(self._make_proj(dx/d*4.5, dy/d*4.5, 28, hp))

    def _shoot_asteroids_triple(self, target):
        dx = target[0]-self.x; dy = target[1]-self.y
        d  = math.hypot(dx, dy)
        if d == 0:
            return
        base = math.atan2(dy, dx)
        for off in [-0.35, 0, 0.35]:
            a = base + off
            self.projectiles.append(self._make_proj(math.cos(a)*4.5, math.sin(a)*4.5, 24, 2))

    def _shoot_asteroids_spiral(self, _target):
        for i in range(6):
            a = math.radians(self.orbit_angle * 57.3 + i * 60)
            self.projectiles.append(self._make_proj(math.cos(a)*3.5, math.sin(a)*3.5, 20, 1))

    # ── Dégâts ────────────────────────────────────────────────────────────────

    def take_damage(self, amount):
        self.vie -= amount
        if   self.vie <= 0:                      self.defeated = True
        elif self.vie <= 66 and self.phase == 1: self.phase = 2
        elif self.vie <= 33 and self.phase == 2: self.phase = 3

    # ── Rendu ─────────────────────────────────────────────────────────────────

    def draw(self, surface):
        if self.defeated:
            return
        bx, by = int(self.x), int(self.y)
        sc = min(state.WIDTH/1600, state.HEIGHT/900)

        draw_outline_glow(surface, (bx, by), self.size//2+10, PURPLE_BOSS, 4)

        if state.boss_raw_img:
            img = pygame.transform.scale(state.boss_raw_img, (self.size, self.size))
            img = pygame.transform.rotate(img, self.rot_angle)
            surface.blit(img, img.get_rect(center=(bx, by)))
        else:
            pygame.draw.circle(surface, PURPLE_BOSS, (bx, by), self.size//2)
            pygame.draw.rect(surface, RED_DANGER, (bx, by), self.size//2, 3)

        # Barre de vie
        bw = int(300*sc); bh = int(20*sc)
        bxb = state.WIDTH//2 - bw//2
        byb = state.RECT_JEU.top + int(50*sc)
        pygame.draw.rect(surface, RED_DARK,   (bxb, byb, bw, bh))
        pygame.draw.rect(surface, RED_DANGER, (bxb, byb, int(self.vie/self.vie_max*bw), bh))
        pygame.draw.rect(surface, TERM_GREEN, (bxb, byb, bw, bh), 2)

        phase_cols = {1: SILVER, 2: YELLOW_GOLD, 3: RED_DANGER}
        bt = state.font_big.render(
            f"COMMANDANT SUPRÊME - Phase {self.phase}", True, phase_cols.get(self.phase, WHITE))
        surface.blit(bt, bt.get_rect(center=(state.WIDTH//2, byb-28)))

        # Projectiles du boss
        for proj in self.projectiles:
            px2, py2 = int(proj['x']), int(proj['y'])
            draw_outline_glow(surface, (px2, py2), proj['size'], GREY_ROCK, 2)
            if state.asteroide_img:
                sz = proj['size'] * 2
                ai = pygame.transform.scale(state.asteroide_img, (sz, sz))
                ai = pygame.transform.rotate(ai, proj['rotation'])
                surface.blit(ai, ai.get_rect(center=(px2, py2)))
            else:
                pygame.draw.circle(surface, GREY_ROCK, (px2, py2), proj['size'])
            if proj['hp'] > 1:
                ht = state.font_item.render(str(proj['hp']), True, WHITE)
                surface.blit(ht, (px2-5, py2-5))
