"""
main.py — Boucle principale, événements, reset (Mission Orion)
Point d'entrée du jeu.

Compatible pygbag (web/WebAssembly) ET exécution locale standard :
la boucle de jeu est encapsulée dans une fonction async + asyncio.run().
"""

import math
import random
import datetime
import asyncio
import pygame

import state
import procedural
from config import (
    SHOOT_DELAY, BULLET_SPEED, ALIEN_BASE_SPEED, ASTEROIDE_BASE_SPEED,
    BONUS_FALL_SPEED, MECANO_REPLIQUES, INTRO_TOTAL_SCENES,
    TAILLE_FENETRE_DEFAULT, LASER_COLOR,
    # Palette
    ACCENT, ACCENT_CYAN, SPACE_1, TEXT_MAIN, TEXT_SOFT, PANEL_BORDER,
    YELLOW_GOLD, RED_DANGER, GREEN_OK, GREY_ROCK, ORANGE_EXPLOSION,
    GLOW_ENEMY_COLOR,
    # Alias rétro-compat (encore utilisés ici)
    TERM_GREEN, TERM_GREEN_BRIGHT, TERM_GREEN_DIM, TERM_GREEN_TEXT,
)
from assets import (
    update_fonts, recalculer_zones, rescale_all_images, charger_ressources,
)
from entities import Boss, create_explosion, create_bomb_explosion, draw_outline_glow
from drawing import (
    draw_text_simple, dessiner_arsenal, dessiner_bouton_verre,
    dessiner_popup_assistant_corner, dessiner_cadre_pixel,
)
from screens import (
    dessiner_intro_cinematique, dessiner_popup_assistant, dessiner_popup_mecanicien,
    dessiner_garage,
    dessiner_ecran_credits, dessiner_menu_principal,
)
from utils import (
    sauver_progression, lire_progression,
    jouer_son, get_niveau_actuel, verifier_avancement_niveau,
    get_alien_image, get_asteroide_image, make_tinted_bullet, get_player_img_tinted,
    set_popup_assistant, tick_popup_ambiance, planifier_premier_popup_ambiance,
)


# ── Initialisation ─────────────────────────────────────────────────────────────

pygame.init()
pygame.mixer.init()

state.screen = pygame.display.set_mode(TAILLE_FENETRE_DEFAULT)
pygame.display.set_caption("Mission Orion - Retour à la Maison")
state.clock  = pygame.time.Clock()
state.WIDTH, state.HEIGHT = state.screen.get_size()

update_fonts()
recalculer_zones()
charger_ressources()
rescale_all_images()
lire_progression()

if pygame.mixer.music.get_busy() is not None:
    try:
        pygame.mixer.music.set_volume(state.volume_music)
        pygame.mixer.music.play(-1)
    except Exception:
        pass


# ── Helpers ────────────────────────────────────────────────────────────────────

def make_rect(cx, cy, w, h):
    return pygame.Rect(int(cx-w//2), int(cy-h//2), int(w), int(h))


def update_button_positions():
    sw = state.WIDTH/1600; sh = state.HEIGHT/900
    jcx = state.RECT_JEU.centerx; jcy = state.RECT_JEU.centery

    state.bouton_relancer = make_rect(jcx, jcy+int(110*sh), int(200*sw), int(60*sh))
    state.bouton_start    = make_rect(state.WIDTH//2, state.HEIGHT//2+int(90*sh), int(440*sw), int(60*sh))
    pause_sz = max(int(70*sw), int(70*sh))
    pause_m  = max(int(12*sw), int(12*sh))
    state.bouton_pause_icone = pygame.Rect(
        state.RECT_JEU.right-pause_sz-pause_m, state.RECT_JEU.top+pause_m, pause_sz, pause_sz)

    # Boutons pause (4 boutons, sans options)
    for i, attr in enumerate(['bouton_reprendre_pause','bouton_recommencer_pause',
                               'bouton_quitter_pause','bouton_menu_principal_pause']):
        setattr(state, attr, make_rect(jcx, jcy+int((-90+i*60)*sh), int(280*sw), int(50*sh)))

    # Menu principal — 2 boutons : JOUER / QUITTER
    btn_h = int(55*sh); btn_w = int(270*sw); gap = int(82*sh)
    base_y = state.HEIGHT//2 + int(20*sh)
    for i, attr in enumerate(['bouton_menu_histoire', 'bouton_menu_quitter']):
        setattr(state, attr, make_rect(state.WIDTH//2, base_y+i*gap, btn_w, btn_h))

    state.bouton_quitter_gameover = make_rect(jcx, jcy+int(185*sh), int(200*sw), int(60*sh))


# ── Reset jeu ─────────────────────────────────────────────────────────────────

def reset_game(skip_tutorial=False):
    # Entités
    state.bullets       = []
    state.enemies       = []
    state.bonuses_drops = []
    state.particles     = []
    state.inventory     = []
    state.boss_actif    = None

    # Joueur
    state.selected_item_index = 0
    state.compteur            = 0
    state.vies                = 3
    state.laser_level         = 1
    state.last_shot_time      = 0
    state.max_vies_actuel     = 5
    state.max_laser_level     = 4

    # Flags d'écran
    state.game_over      = False
    state.victoire       = False
    state.en_pause       = False
    state.credits_active = False

    # Spawn et timers
    state.spawn_delay      = 60
    state.hud_damage_timer = 0
    state.halo_red_timer   = 0

    # Gameplay spécial
    state.transition_active  = False
    state.bomb_anim_active   = False
    state.bomb_radius        = 0
    state.bomb_hit_boss      = False
    state.bouclier_actif     = False
    state.bouclier_permanent = False
    state.fade_active        = False
    state.fade_alpha         = 0

    # Garage
    state.garage_actif         = False
    state.garage_choices_made  = set()
    state.garage_mecano_phase  = False
    state.garage_mecano_message = ""

    # Niveaux
    state.niveau_courant_id   = 0
    state.niveau_precedent_id = -1

    # Popups
    state.popup_assistant_msg      = ""
    state.popup_assistant_until    = 0
    state.popup_assistant_priority = 0
    planifier_premier_popup_ambiance()

    if skip_tutorial:
        state.intro_active         = False
        state.countdown_active     = True
        state.countdown_start_time = pygame.time.get_ticks()
    else:
        state.intro_active = True
        state.intro_state  = 0
        state.intro_scene  = 0
        state.tuto_step    = 0


# ── Boucle principale (async pour pygbag/web compatibility) ────────────────────

async def main():
    update_button_positions()

    while state.running:
        update_button_positions()
        sc = min(state.WIDTH/1600, state.HEIGHT/900)
        niveau_actuel = get_niveau_actuel()

        # ── Événements ──────────────────────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                state.running = False

            # ── Menu principal ────────────────────────────────────────────────
            if state.start_menu_active:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    mx, my = event.pos
                    if state.bouton_menu_histoire.collidepoint(mx, my):
                        state.start_menu_active = False; state.input_active = True
                    elif state.bouton_menu_quitter.collidepoint(mx, my):
                        state.running = False

            elif state.credits_active:
                if event.type == pygame.MOUSEBUTTONDOWN or \
                   (event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE):
                    state.credits_active = False
                    state.start_menu_active = True

            elif state.garage_actif:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    mx3, my3 = event.pos
                    if state.garage_mecano_phase:
                        state.garage_mecano_phase = False; continue
                    if state.garage_intro_active:
                        if state.garage_intro_phase == 0:
                            state.garage_intro_phase = 1; state.garage_intro_start = pygame.time.get_ticks()
                        elif state.garage_intro_phase == 1:
                            state.garage_intro_phase = 2; state.garage_intro_active = False
                    else:
                        if len(state.garage_choices_made) == 0:
                            for idx, btn in enumerate([state.bouton_garage_vie,
                                                       state.bouton_garage_bouclier,
                                                       state.bouton_garage_tir]):
                                if btn.collidepoint(mx3, my3):
                                    state.garage_choices_made.add(idx)
                                    if idx == 0:
                                        state.max_vies_actuel = 7
                                        state.vies = min(state.vies+2, state.max_vies_actuel)
                                        set_popup_assistant(f"Vie +2 ! Max monté à 7 ! ({state.vies}/{state.max_vies_actuel} PV)")
                                    elif idx == 1:
                                        state.bouclier_permanent = True; state.bouclier_actif = True
                                        set_popup_assistant("Bouclier Mk.IV actif par vague !")
                                    elif idx == 2:
                                        state.max_laser_level = min(state.max_laser_level+1, 5)
                                        state.laser_level = max(2, min(state.laser_level+1, state.max_laser_level))
                                        set_popup_assistant(f"Laser niveau {state.laser_level} ! Max: {state.max_laser_level}, Min: 2 !")
                                    repliques = MECANO_REPLIQUES.get(idx, ["Amélioration installée !"])
                                    state.garage_mecano_message = random.choice(repliques)
                                    state.garage_mecano_phase = True
                                    jouer_son(state.son_bonus); break
                        if state.bouton_garage_partir.collidepoint(mx3, my3):
                            state.garage_actif = False; state.garage_choices_made = set()
                            state.garage_mecano_phase = False

            elif state.intro_active:
                # Le bouton pause reste cliquable pendant l'intro / le tuto
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if state.bouton_pause_icone.collidepoint(event.pos):
                        state.en_pause = not state.en_pause
                        continue
                    if state.en_pause:
                        if state.bouton_reprendre_pause.collidepoint(event.pos):
                            state.en_pause = False
                        elif state.bouton_menu_principal_pause.collidepoint(event.pos):
                            state.en_pause = False
                            state.intro_active = False; state.input_active = False
                            state.start_menu_active = True
                        elif state.bouton_quitter_pause.collidepoint(event.pos):
                            state.running = False
                        # Pas de "RECOMMENCER" pendant l'intro : on ignore le bouton
                        continue
                # Pendant la pause on n'avance pas les scènes / tuto
                if state.en_pause:
                    continue
                if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
                    if state.intro_state == 0:
                        state.intro_scene += 1
                        if state.intro_scene >= INTRO_TOTAL_SCENES:
                            state.intro_state = 1; state.intro_scene = 0
                    elif state.intro_state == 1:
                        state.tuto_step += 1
                        if state.tuto_step > 2:
                            state.intro_active = False
                            state.countdown_active = True
                            state.countdown_start_time = pygame.time.get_ticks()

            elif state.input_active:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        state.pseudo = state.pseudo[:-1]
                    elif len(state.pseudo) < 10 and event.unicode.isprintable() and event.unicode:
                        state.pseudo += event.unicode
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if state.bouton_start.collidepoint(event.pos) and state.pseudo:
                        state.input_active = False
                        state.intro_active = True
                        state.intro_state  = 0
                        state.tuto_step    = 0
                        state.niveau_courant_id   = 0
                        state.niveau_precedent_id = -1

            elif not state.game_over and not state.victoire and not state.countdown_active and not state.credits_active:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    if state.transition_active: state.transition_active = False; state.enemies = []

                if event.type == pygame.MOUSEWHEEL:
                    if state.inventory:
                        state.selected_item_index = (state.selected_item_index + (-1 if event.y > 0 else 1)) % len(state.inventory)

                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx2, my2 = event.pos
                    if event.button == 1 and state.bouton_pause_icone.collidepoint(mx2, my2):
                        state.en_pause = not state.en_pause

                    elif state.en_pause:
                        if event.button == 1:
                            if state.bouton_reprendre_pause.collidepoint(mx2, my2):
                                state.en_pause = False
                            elif state.bouton_recommencer_pause.collidepoint(mx2, my2):
                                reset_game(skip_tutorial=True)
                            elif state.bouton_quitter_pause.collidepoint(mx2, my2):
                                state.running = False
                            elif state.bouton_menu_principal_pause.collidepoint(mx2, my2):
                                state.en_pause = False
                                state.game_over = False; state.victoire = False
                                state.bullets = []; state.enemies = []; state.bonuses_drops = []; state.particles = []
                                state.boss_actif = None; state.garage_actif = False
                                state.start_menu_active = True
                                state.intro_active = False; state.input_active = False

                    elif not state.transition_active:
                        if event.button == 1 and state.RECT_JEU.collidepoint(mx2, my2):
                            ct = pygame.time.get_ticks()
                            if ct - state.last_shot_time > SHOOT_DELAY:
                                state.last_shot_time = ct
                                dx = mx2-state.center_jeu[0]; dy = my2-state.center_jeu[1]
                                dist = math.hypot(dx, dy)
                                if dist > 0:
                                    ang = math.degrees(math.atan2(-dy, dx))
                                    offsets = {1:[0],2:[-5,5],3:[-8,0,8],4:[-12,-4,4,12],5:[-14,-7,0,7,14]}
                                    for off in offsets.get(state.laser_level, [0]):
                                        a2  = ang + off; rad2 = math.radians(a2)
                                        vx2 = math.cos(rad2)*BULLET_SPEED
                                        vy2 = -math.sin(rad2)*BULLET_SPEED
                                        ir  = make_tinted_bullet(a2)
                                        state.bullets.append({'rect':pygame.Rect(state.center_jeu[0],state.center_jeu[1],8,8),
                                                              'vx':vx2,'vy':vy2,'image':ir,'color':LASER_COLOR})
                                    jouer_son(state.son_tir)
                        if event.button == 4 and state.inventory:
                            state.selected_item_index = (state.selected_item_index-1) % len(state.inventory)
                        if event.button == 5 and state.inventory:
                            state.selected_item_index = (state.selected_item_index+1) % len(state.inventory)
                        if event.button == 3 and state.inventory:
                            state.selected_item_index = min(state.selected_item_index, len(state.inventory)-1)
                            itype = state.inventory.pop(state.selected_item_index)
                            if state.inventory:
                                state.selected_item_index = min(state.selected_item_index, len(state.inventory)-1)
                            if itype == "bombe":
                                state.bomb_anim_active = True; state.bomb_radius = 10
                                state.bomb_hit_boss = False
                                set_popup_assistant("BOMBE !"); jouer_son(state.son_explosion)
                            elif itype == "vie":
                                if state.vies < state.max_vies_actuel:
                                    state.vies += 1; set_popup_assistant("VIE +1"); jouer_son(state.son_bonus)
                                else: set_popup_assistant(f"Vie au maximum ({state.max_vies_actuel}) !")
                                state.halo_red_timer = 45
                            elif itype == "laser":
                                if state.laser_level < state.max_laser_level:
                                    state.laser_level += 1; set_popup_assistant("LASER +1 !"); jouer_son(state.son_bonus)
                                else: set_popup_assistant(f"Laser au max ({state.max_laser_level}) !")

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if state.game_over and state.bouton_quitter_gameover.collidepoint(event.pos):
                    state.running = False
                elif (state.game_over or state.victoire) and state.bouton_relancer.collidepoint(event.pos):
                    if state.victoire and not state.credits_active:
                        state.credits_active = True; state.victoire = False
                    else:
                        reset_game(skip_tutorial=True)

        # ── Dessin ──────────────────────────────────────────────────────────────
        state.screen.fill((22, 38, 78))

        # Fond du niveau (plein écran)
        if state.start_menu_active or state.input_active:
            state.screen.blit(procedural.get_fond_procedural(0, state.RECT_JEU.width, state.RECT_JEU.height), state.RECT_JEU)
        elif state.intro_active:
            state.screen.blit(procedural.get_fond_procedural(0, state.RECT_JEU.width, state.RECT_JEU.height), state.RECT_JEU)
        elif state.fade_active:
            fp = procedural.get_fond_pour_niveau(state.niveau_precedent_id if state.niveau_precedent_id >= 0 else 0,
                                                 state.RECT_JEU.width, state.RECT_JEU.height)
            state.screen.blit(fp, state.RECT_JEU)
            fs = procedural.get_fond_pour_niveau(niveau_actuel['id'], state.RECT_JEU.width, state.RECT_JEU.height)
            fs_copy = fs.copy(); fs_copy.set_alpha(state.fade_alpha); state.screen.blit(fs_copy, state.RECT_JEU)
            state.fade_alpha += 5
            if state.fade_alpha >= 255: state.fade_active = False
        else:
            fond_niv = procedural.get_fond_pour_niveau(niveau_actuel['id'], state.RECT_JEU.width, state.RECT_JEU.height)
            state.screen.blit(fond_niv, state.RECT_JEU)

        # HUD dégâts
        if state.hud_damage_timer > 0:
            state.hud_damage_timer -= 1
            sh2 = pygame.Surface((state.WIDTH, state.HEIGHT), pygame.SRCALPHA)
            sh2.fill((120,0,0,60))
            state.screen.blit(sh2, (0,0))

        # ── Compte à rebours ────────────────────────────────────────────────────
        if state.countdown_active:
            mx2, my2 = pygame.mouse.get_pos()
            p_img = get_player_img_tinted()
            angle = math.degrees(math.atan2(-(my2-state.center_jeu[1]), mx2-state.center_jeu[0]))
            rp = pygame.transform.rotate(p_img, angle)
            state.screen.blit(rp, rp.get_rect(center=state.center_jeu))
            for i in range(state.max_vies_actuel):
                ico = state.vie_img if i < state.vies else state.vie_grise_img
                state.screen.blit(ico, (state.RECT_JEU.centerx-int(140*sc)+i*int(40*sc), state.RECT_JEU.top+int(90*sc)))
            te = (pygame.time.get_ticks() - state.countdown_start_time) / 1000
            compte = 3 - int(te)
            if compte > 0:
                ct2 = state.font_huge.render(str(compte), True, TERM_GREEN)
                state.screen.blit(ct2, ct2.get_rect(center=(state.RECT_JEU.centerx, state.RECT_JEU.centery+int(100*sc))))
            else:
                ct3 = state.font_huge.render("GO!", True, TERM_GREEN_BRIGHT)
                state.screen.blit(ct3, ct3.get_rect(center=(state.RECT_JEU.centerx, state.RECT_JEU.centery+int(100*sc))))
                if te > 3.5:
                    state.countdown_active = False
                    set_popup_assistant("Feu à volonté !")

        # ── Jeu en cours ────────────────────────────────────────────────────────
        elif (not state.game_over and not state.victoire and not state.input_active and
              not state.intro_active and not state.start_menu_active and not state.garage_actif and
              not state.credits_active):

            verifier_avancement_niveau()

            if niveau_actuel['id'] != state.niveau_precedent_id:
                if state.niveau_precedent_id != -1:
                    state.fade_active = True; state.fade_alpha = 0
                    if niveau_actuel.get('est_garage'):
                        state.garage_actif = True; state.garage_choices_made = set()
                        state.garage_intro_active = True; state.garage_intro_phase = 0
                        state.garage_intro_start = pygame.time.get_ticks()
                        state.garage_mecano_phase = False
                    elif niveau_actuel.get('est_boss'):
                        state.transition_active = True; state.transition_start = pygame.time.get_ticks()
                        state.transition_message = niveau_actuel['message_entree']
                        state.transition_duree_cur = niveau_actuel['transition_duree']
                        state.enemies = []; state.bullets = []
                        state.boss_actif = Boss(state.center_jeu[0], state.center_jeu[1])
                        if state.bouclier_permanent: state.bouclier_actif = True
                    else:
                        state.transition_active = True; state.transition_start = pygame.time.get_ticks()
                        state.transition_message = niveau_actuel['message_entree']
                        state.transition_duree_cur = niveau_actuel['transition_duree']
                        state.enemies = []; state.bullets = []
                        if state.bouclier_permanent: state.bouclier_actif = True
                state.niveau_precedent_id = niveau_actuel['id']

            if state.transition_active:
                dessiner_popup_assistant(state.screen, state.transition_message)
                if pygame.time.get_ticks()-state.transition_start > state.transition_duree_cur:
                    state.transition_active = False

            # Nom du niveau
            tn2 = state.font_big.render(niveau_actuel['nom'], True, TERM_GREEN_BRIGHT)
            rn = tn2.get_rect(center=(state.RECT_JEU.centerx, state.RECT_JEU.top+int(50*sc)))
            bgs = pygame.Surface((rn.width+20, rn.height+10), pygame.SRCALPHA)
            bgs.fill((4,10,25,160)); state.screen.blit(bgs,(rn.x-10,rn.y-5)); state.screen.blit(tn2,rn)

            if not state.en_pause:
                # Balles
                for b in state.bullets[:]:
                    b['rect'].x += b['vx']; b['rect'].y += b['vy']
                    if not state.RECT_JEU.colliderect(b['rect']): state.bullets.remove(b)

                # ── Boss ──────────────────────────────────────────────────────
                if state.boss_actif:
                    state.boss_actif.update(state.center_jeu)
                    if state.boss_actif.defeated:
                        state.victoire = True
                        state.histoire_complete = True
                        sauver_progression()
                        set_popup_assistant("VICTOIRE ! Mission accomplie !")
                        state.boss_actif = None
                    else:
                        bh2b = pygame.Rect(state.boss_actif.x-state.boss_actif.size//2,
                                           state.boss_actif.y-state.boss_actif.size//2,
                                           state.boss_actif.size, state.boss_actif.size)
                        for b in state.bullets[:]:
                            if b['rect'].colliderect(bh2b):
                                state.bullets.remove(b); state.boss_actif.take_damage(1); jouer_son(state.son_explosion)
                        pr2 = pygame.Rect(state.center_jeu[0]-state.player_size//2,
                                          state.center_jeu[1]-state.player_size//2,
                                          state.player_size, state.player_size)
                        for proj in state.boss_actif.projectiles[:]:
                            pj_r = pygame.Rect(proj['x']-proj['size'], proj['y']-proj['size'],
                                               proj['size']*2, proj['size']*2)
                            hit = False
                            for b in state.bullets[:]:
                                if b['rect'].colliderect(pj_r):
                                    state.bullets.remove(b); proj['hp'] -= 1
                                    if proj['hp'] <= 0:
                                        if proj in state.boss_actif.projectiles: state.boss_actif.projectiles.remove(proj)
                                        create_explosion(proj['x'], proj['y'], ORANGE_EXPLOSION)
                                        jouer_son(state.son_explosion); hit = True
                                    break
                            if not hit and proj in state.boss_actif.projectiles:
                                if pj_r.colliderect(pr2):
                                    state.boss_actif.projectiles.remove(proj)
                                    if state.bouclier_actif:
                                        state.bouclier_actif = False; set_popup_assistant("Bouclier absorbé !")
                                    else:
                                        state.vies -= 1; state.hud_damage_timer = 10; jouer_son(state.son_degat)
                                        set_popup_assistant("TOUCHÉ !")
                                        if state.vies <= 0: state.game_over = True
                        # Bombe vs boss (une seule fois par bombe, dégâts modérés)
                        if state.bomb_anim_active and not state.bomb_hit_boss:
                            if math.hypot(state.boss_actif.x-state.center_jeu[0],
                                           state.boss_actif.y-state.center_jeu[1]) < state.bomb_radius + state.boss_actif.size//2:
                                degats_bombe_boss = 80
                                state.boss_actif.take_damage(degats_bombe_boss)
                                state.bomb_hit_boss = True
                                create_bomb_explosion(int(state.boss_actif.x), int(state.boss_actif.y))
                                set_popup_assistant(f"BOMBE SUR LE BOSS ! -{degats_bombe_boss} PV !")
                                jouer_son(state.son_explosion)

                # ── Ennemis normaux ───────────────────────────────────────────
                else:
                    sd2 = niveau_actuel['spawn_delay']

                    if not state.transition_active and not state.bomb_anim_active:
                        state.spawn_timer += 1
                        if state.spawn_timer >= sd2:
                            state.spawn_timer = 0
                            te2 = niveau_actuel.get('type_ennemi')
                            if te2 == 'alien':   tp='alien'; at2=niveau_actuel.get('alien_type','alien1')
                            elif te2 == 'asteroide': tp='asteroide'; at2=None
                            elif te2 == 'mixte':
                                ratio = niveau_actuel.get('ratio_alien',0.5)
                                tp='alien' if random.random()<ratio else 'asteroide'
                                at2 = niveau_actuel.get('alien_type','alien1') if tp=='alien' else None
                            elif te2 == 'armada': tp='alien'; at2=random.choice(['alien1','alien2','alien3'])
                            else: tp=None; at2=None
                            if tp:
                                side = random.randint(0,3)
                                if side==0:   ex=random.randint(state.RECT_JEU.left,state.RECT_JEU.right); ey=state.RECT_JEU.top-50
                                elif side==1: ex=random.randint(state.RECT_JEU.left,state.RECT_JEU.right); ey=state.RECT_JEU.bottom+50
                                elif side==2: ex=state.RECT_JEU.left-50; ey=random.randint(state.RECT_JEU.top,state.RECT_JEU.bottom)
                                else:         ex=state.RECT_JEU.right+50; ey=random.randint(state.RECT_JEU.top,state.RECT_JEU.bottom)
                                state.enemies.append({'rect':pygame.Rect(ex,ey,state.alien_size,state.alien_size),
                                                      'type':tp,'alien_type':at2,'vit_mult':1.0})

                    # Bonus
                    if random.randint(0,800)==0 and not state.transition_active:
                        rv = random.random()
                        state.bonuses_drops.append({'rect':pygame.Rect(
                            random.randint(state.RECT_JEU.left+50,state.RECT_JEU.right-50),-50,40,40),
                            'type':"bombe" if rv<0.45 else ("vie" if rv<0.85 else "laser")})

                    for bon in state.bonuses_drops[:]:
                        bon['rect'].y += BONUS_FALL_SPEED
                        if bon['rect'].y > state.HEIGHT: state.bonuses_drops.remove(bon); continue
                        for b in state.bullets[:]:
                            if b['rect'].colliderect(bon['rect']):
                                state.bullets.remove(b); state.bonuses_drops.remove(bon)
                                if len(state.inventory) < 4:
                                    state.inventory.append(bon['type'])
                                    set_popup_assistant("Bonus récupéré !"); jouer_son(state.son_bonus)
                                else: set_popup_assistant("Arsenal plein !")
                                break

                    for e in state.enemies[:]:
                        dx2=state.center_jeu[0]-e['rect'].centerx; dy2=state.center_jeu[1]-e['rect'].centery
                        d2=math.hypot(dx2,dy2)
                        vit=(ASTEROIDE_BASE_SPEED if e['type']=='asteroide' else ALIEN_BASE_SPEED)
                        vit=(vit+niveau_actuel.get('vitesse_bonus',0)) * e.get('vit_mult',1.0)
                        if d2>0: e['rect'].x+=dx2/d2*vit; e['rect'].y+=dy2/d2*vit

                        pr3=pygame.Rect(state.center_jeu[0]-state.player_size//2,
                                        state.center_jeu[1]-state.player_size//2, state.player_size, state.player_size)
                        if e['rect'].colliderect(pr3):
                            state.enemies.remove(e)
                            create_explosion(e['rect'].centerx, e['rect'].centery,
                                             GREY_ROCK if e['type']=='asteroide' else GREEN_OK)
                            jouer_son(state.son_explosion)
                            if not state.transition_active and not state.bouclier_actif:
                                state.vies -= 1; state.hud_damage_timer = 10; jouer_son(state.son_degat)
                                min_laser = 2 if 2 in state.garage_choices_made else 1
                                if state.laser_level > min_laser:
                                    state.laser_level = max(min_laser, state.laser_level-1)
                                    set_popup_assistant("ARMEMENT TOUCHÉ !")
                                else: set_popup_assistant("COQUE CRITIQUE !")
                                if state.vies <= 0: state.game_over = True
                            elif state.bouclier_actif:
                                state.bouclier_actif = False; set_popup_assistant("Bouclier absorbé !")
                            continue
                        for b in state.bullets[:]:
                            if b['rect'].colliderect(e['rect']):
                                state.bullets.remove(b); state.enemies.remove(e)
                                create_explosion(e['rect'].centerx, e['rect'].centery,
                                                 GREY_ROCK if e['type']=='asteroide' else GREEN_OK)
                                jouer_son(state.son_explosion)
                                state.compteur += 2 if e['type']=='asteroide' else 1; break

                    # Bombe
                    if state.bomb_anim_active:
                        for e in state.enemies[:]:
                            if math.hypot(e['rect'].centerx-state.center_jeu[0],
                                           e['rect'].centery-state.center_jeu[1]) < state.bomb_radius+30:
                                state.enemies.remove(e)
                                create_bomb_explosion(e['rect'].centerx, e['rect'].centery)
                                state.compteur += 2 if e['type']=='asteroide' else 1
                        state.bomb_radius += 25
                        if state.bomb_radius > state.bomb_max_radius: state.bomb_anim_active = False

                # Particules communes (boss ou normal)
                for p in state.particles[:]:
                    p['x']+=p['vx']; p['y']+=p['vy']; p['life']-=1
                    if p['life']<=0 or not state.RECT_JEU.collidepoint(p['x'],p['y']): state.particles.remove(p)
                if state.boss_actif and state.bomb_anim_active:
                    state.bomb_radius += 25
                    if state.bomb_radius > state.bomb_max_radius: state.bomb_anim_active = False

                if state.halo_red_timer > 0:
                    state.halo_red_timer -= 1

            # Rendu entités
            for bon in state.bonuses_drops:
                draw_outline_glow(state.screen, bon['rect'].center, state.bonus_size//2, YELLOW_GOLD, 2)
                img2 = state.bonus_img if bon['type']=='bombe' else (state.vie_img if bon['type']=='vie' else state.bonus_laser_img)
                state.screen.blit(img2, img2.get_rect(center=bon['rect'].center))
            for b in state.bullets:
                state.screen.blit(b['image'], b['image'].get_rect(center=b['rect'].center))
            for e in state.enemies:
                col3 = GREY_ROCK if e['type']=='asteroide' else GLOW_ENEMY_COLOR
                r_glow = state.asteroide_size//2 if e['type']=='asteroide' else state.alien_size//2
                draw_outline_glow(state.screen, e['rect'].center, r_glow, col3, 3)
                img2 = get_asteroide_image() if e['type']=='asteroide' else get_alien_image(e.get('alien_type','alien1'))
                state.screen.blit(img2, img2.get_rect(center=e['rect'].center))
            for p in state.particles:
                pygame.draw.rect(state.screen, p['color'], (p['x'],p['y'],p['size'],p['size']))

            if state.boss_actif: state.boss_actif.draw(state.screen)

            # Joueur
            mx2, my2 = pygame.mouse.get_pos()
            p_img = get_player_img_tinted()
            angle = math.degrees(math.atan2(-(my2-state.center_jeu[1]), mx2-state.center_jeu[0]))
            rp2 = pygame.transform.rotate(p_img, angle)
            state.screen.blit(rp2, rp2.get_rect(center=state.center_jeu))

            # Bouclier visuel
            if state.bouclier_actif:
                bs3 = pygame.Surface((state.player_size*3, state.player_size*3), pygame.SRCALPHA)
                rr  = state.player_size + int(10*math.sin(pygame.time.get_ticks()*0.005))
                pygame.draw.circle(bs3,(60,160,255,100),(state.player_size*3//2,state.player_size*3//2),rr,3)
                state.screen.blit(bs3,(state.center_jeu[0]-state.player_size*3//2,state.center_jeu[1]-state.player_size*3//2))

            if state.halo_red_timer > 0:
                hr = pygame.Surface((int(120*sc),int(120*sc)),pygame.SRCALPHA)
                pygame.draw.circle(hr,(255,0,0,80),(int(60*sc),int(60*sc)),int(55*sc))
                state.screen.blit(hr,(state.center_jeu[0]-int(60*sc),state.center_jeu[1]-int(60*sc)))

            # Vies
            v_sp = min(int(40*sc),(state.RECT_JEU.width-50)//max(state.max_vies_actuel,1))
            v_start = state.RECT_JEU.centerx - v_sp*(state.max_vies_actuel//2)
            for i in range(state.max_vies_actuel):
                state.screen.blit(state.vie_img if i<state.vies else state.vie_grise_img,
                                  (v_start+i*v_sp, state.RECT_JEU.top+int(90*sc)))

            # Bombe animée
            if state.bomb_anim_active:
                sb = pygame.Surface((state.RECT_JEU.width, state.RECT_JEU.height), pygame.SRCALPHA)
                r_draw = int(state.bomb_radius)
                pygame.draw.circle(sb,(255,210,0,22),(state.center_jeu[0]-state.RECT_JEU.left,state.center_jeu[1]),r_draw)
                if r_draw>6: pygame.draw.circle(sb,(255,235,50,80),(state.center_jeu[0]-state.RECT_JEU.left,state.center_jeu[1]),r_draw,5)
                if r_draw>30: pygame.draw.circle(sb,(255,200,0,60),(state.center_jeu[0]-state.RECT_JEU.left,state.center_jeu[1]),max(4,r_draw-20),3)
                state.screen.blit(sb, state.RECT_JEU.topleft)

            # Score affiché en jeu (en haut à gauche, sous le pseudo, plus bas et plus gros)
            score_surf = state.font_big.render(f"SCORE  {state.compteur}", True, ACCENT)
            score_x = state.RECT_JEU.x + int(16*sc); score_y = state.RECT_JEU.y + int(86*sc)
            score_rect = pygame.Rect(score_x-8, score_y-6,
                                     score_surf.get_width()+20, score_surf.get_height()+10)
            dessiner_cadre_pixel(state.screen, score_rect, border_color=PANEL_BORDER)
            state.screen.blit(score_surf, (score_x+2, score_y+2))


        elif state.garage_actif:
            if state.garage_intro_active:
                fn_g = procedural.get_fond_procedural(3, state.RECT_JEU.width, state.RECT_JEU.height)
                state.screen.blit(fn_g, state.RECT_JEU)
                elapsed = pygame.time.get_ticks() - state.garage_intro_start
                if state.garage_intro_phase == 0:
                    if elapsed > 5000: state.garage_intro_phase = 1; state.garage_intro_start = pygame.time.get_ticks()
                    else: dessiner_popup_assistant(state.screen, "Station relais détectée !\nMECANO-7 est prêt à vous servir.")
                elif state.garage_intro_phase == 1:
                    if elapsed > 5500: state.garage_intro_active = False
                    else: dessiner_popup_mecanicien(state.screen, "Capitaine ! Bienvenue au garage.\nChoisissez vos améliorations !\nC'est offert par la maison !")
            else:
                dessiner_garage(state.screen)

        elif state.game_over:
            sp3 = pygame.Surface((state.RECT_JEU.width,state.RECT_JEU.height),pygame.SRCALPHA)
            sp3.fill((20,35,80,140)); state.screen.blit(sp3,state.RECT_JEU.topleft)
            t4 = state.font_gameover.render("ÉCHEC",True,RED_DANGER)
            state.screen.blit(t4,t4.get_rect(center=(state.RECT_JEU.centerx,state.RECT_JEU.centery-int(60*sc))))
            s4 = state.font_big.render(f"Score : {state.compteur}",True,TERM_GREEN_TEXT)
            state.screen.blit(s4,s4.get_rect(center=(state.RECT_JEU.centerx,state.RECT_JEU.centery+int(10*sc))))
            dessiner_bouton_verre(state.screen,state.bouton_relancer,"REJOUER",state.font_big)
            dessiner_bouton_verre(state.screen,state.bouton_quitter_gameover,"QUITTER",state.font_big,(255,120,120))

        elif state.victoire:
            sp4 = pygame.Surface((state.RECT_JEU.width,state.RECT_JEU.height),pygame.SRCALPHA)
            sp4.fill((20,35,80,140)); state.screen.blit(sp4,state.RECT_JEU.topleft)
            t5 = state.font_gameover.render("VICTOIRE!",True,GREEN_OK)
            state.screen.blit(t5,t5.get_rect(center=(state.RECT_JEU.centerx,state.RECT_JEU.centery-int(60*sc))))
            s5 = state.font_big.render(f"Score : {state.compteur}",True,TERM_GREEN_TEXT)
            state.screen.blit(s5,s5.get_rect(center=(state.RECT_JEU.centerx,state.RECT_JEU.centery+int(10*sc))))
            dessiner_bouton_verre(state.screen,state.bouton_relancer,"VOIR CRÉDITS",state.font_big)

        # ── Overlays globaux ────────────────────────────────────────────────────

        # Pseudo en jeu (nom du joueur uniquement, plus gros, en haut à gauche)
        if state.pseudo and not state.start_menu_active and not state.input_active and not state.credits_active:
            pseudo_surf = state.font_big.render(state.pseudo.upper(), True, ACCENT)
            px_pos = state.RECT_JEU.x + int(16*sc); py_pos = state.RECT_JEU.y + int(14*sc)
            pseudo_rect = pygame.Rect(px_pos-8, py_pos-6,
                                      pseudo_surf.get_width()+20, pseudo_surf.get_height()+10)
            dessiner_cadre_pixel(state.screen, pseudo_rect, border_color=ACCENT_CYAN)
            state.screen.blit(pseudo_surf, (px_pos+2, py_pos+2))

        # Intro / tutoriel — dessiné AVANT le HUD persistant pour que le masque
        # noir ne recouvre pas la pause / l'arsenal / le popup pendant le tuto.
        en_tuto = state.intro_active and state.intro_state == 1

        # ── HUD persistant (dessiné AVANT l'intro/tuto pour pouvoir être capturé
        #    par le snapshot du tuto sous le cadre jaune) ────────────────────────
        hud_visible = (not state.start_menu_active and not state.input_active
                       and not state.credits_active and not state.game_over
                       and not state.victoire and not state.garage_actif)

        # Arsenal : caché pendant les scènes d'intro (cinematic), visible en jeu
        # et pendant le tuto (où le cadre jaune viendra l'entourer).
        arsenal_visible = hud_visible and (
            not state.intro_active or state.intro_state == 1
        )
        if arsenal_visible:
            dessiner_arsenal(state.screen, state.RECT_ARSENAL_AREA,
                             state.inventory, state.selected_item_index)

        if hud_visible:
            # Bouton pause toujours visible (y compris pendant intro / tuto)
            dessiner_cadre_pixel(state.screen, state.bouton_pause_icone, border_color=ACCENT)
            bar_w = max(6, state.bouton_pause_icone.width // 8)
            bar_h = state.bouton_pause_icone.height // 2
            gap   = bar_w + max(4, state.bouton_pause_icone.width // 14)
            cx_p = state.bouton_pause_icone.centerx
            cy_p = state.bouton_pause_icone.centery
            pygame.draw.rect(state.screen, ACCENT,
                             (cx_p-gap//2-bar_w, cy_p-bar_h//2, bar_w, bar_h))
            pygame.draw.rect(state.screen, ACCENT,
                             (cx_p+gap//2,      cy_p-bar_h//2, bar_w, bar_h))

        # Popup d'ambiance (uniquement en jeu, pas pendant intro/tuto/pause)
        tick_popup_ambiance_en_jeu = (
            hud_visible and not state.intro_active
            and not state.transition_active and not state.en_pause
        )
        if tick_popup_ambiance_en_jeu:
            tick_popup_ambiance()
        now_ms = pygame.time.get_ticks()
        if (now_ms < state.popup_assistant_until and state.popup_assistant_msg
                and not state.transition_active and not state.intro_active
                and hud_visible):
            dessiner_popup_assistant_corner(state.screen, state.RECT_POPUP_ASSISTANT,
                                             state.popup_assistant_msg)

        # ── Intro cinématique (cache l'arsenal et le pause sous le décor)
        if state.intro_active and state.intro_state == 0:
            dessiner_intro_cinematique(state.screen, state.intro_scene)

        if en_tuto:
            # Vaisseau visible au centre pour le step 0
            p_img = get_player_img_tinted()
            state.screen.blit(p_img, p_img.get_rect(center=state.center_jeu))

            ship_target = pygame.Rect(
                state.center_jeu[0]-state.player_size//2 - int(10*sc),
                state.center_jeu[1]-state.player_size//2 - int(10*sc),
                state.player_size + int(20*sc), state.player_size + int(20*sc))
            orion_target   = state.RECT_POPUP_ASSISTANT
            arsenal_target = state.RECT_ARSENAL_AREA

            ORION_TUTO_MSG = "Salut, c'est moi !\nMes infos s'affichent ici\ntoute la mission."
            targets_data = [
                (ship_target,
                 "VOTRE VAISSEAU\nSOURIS : orienter\nCLIC GAUCHE : tirer", False),
                (orion_target, ORION_TUTO_MSG, True),
                (arsenal_target,
                 "ARSENAL\nMOLETTE : changer d'objet\nCLIC DROIT : utiliser l'objet", False),
            ]

            def _calc_text_rect(target, txt):
                fnt = state.font_lore
                lines = txt.split('\n')
                line_h = fnt.get_linesize()
                text_w = max(fnt.size(l)[0] for l in lines)
                text_h = line_h * len(lines)
                pad_x, pad_y = int(18*sc), int(14*sc)
                box_w = text_w + pad_x * 2
                box_h = text_h + pad_y * 2
                if target.centerx < state.WIDTH // 2:
                    x = min(state.WIDTH - box_w - int(20*sc), target.right + int(24*sc))
                else:
                    x = max(int(20*sc), target.left - box_w - int(24*sc))
                y = max(int(20*sc),
                        min(state.HEIGHT - box_h - int(60*sc),
                            target.centery - box_h // 2))
                return pygame.Rect(x, y, box_w, box_h)

            if state.tuto_step < len(targets_data):
                tgt, txt, est_orion = targets_data[state.tuto_step]
                # Snapshot de la zone surlignée AVANT le masque (arsenal/pause
                # ont déjà été dessinés au-dessus, ils seront dans le snapshot)
                safe = tgt.clip(state.screen.get_rect())
                snap = state.screen.subsurface(safe).copy() if safe.width>0 and safe.height>0 else None
                mask2 = pygame.Surface((state.WIDTH,state.HEIGHT),pygame.SRCALPHA)
                mask2.fill((0,0,0,220)); state.screen.blit(mask2,(0,0))
                if snap: state.screen.blit(snap,safe.topleft)

                if est_orion:
                    # Cas O.R.I.O.N. : on affiche son vrai popup avec le texte du tuto
                    dessiner_popup_assistant_corner(state.screen,
                                                    state.RECT_POPUP_ASSISTANT, txt)
                    pygame.draw.rect(state.screen, ACCENT, state.RECT_POPUP_ASSISTANT, 3)
                else:
                    pygame.draw.rect(state.screen, ACCENT, tgt, 3)
                    txt_rect = _calc_text_rect(tgt, txt)
                    dessiner_cadre_pixel(state.screen, txt_rect, border_color=ACCENT_CYAN)
                    draw_text_simple(state.screen, txt, TEXT_MAIN,
                                     txt_rect.x + int(18*sc), txt_rect.y + int(14*sc),
                                     state.font_lore)

                step_t = state.font_item.render(
                    f"Étape {state.tuto_step+1}/3  ·  Cliquez pour continuer",
                    True, TEXT_SOFT)
                state.screen.blit(step_t, step_t.get_rect(center=(state.RECT_JEU.centerx, state.HEIGHT-30)))

        # Overlay pause — disponible en jeu, intro et tuto
        if state.en_pause and hud_visible:
            sp2 = pygame.Surface((state.RECT_JEU.width, state.RECT_JEU.height), pygame.SRCALPHA)
            sp2.fill((*SPACE_1, 220)); state.screen.blit(sp2, state.RECT_JEU.topleft)
            title2 = state.font_gameover.render("PAUSE", True, ACCENT)
            title_sh = state.font_gameover.render("PAUSE", True, SPACE_1)
            tr = title2.get_rect(center=(state.RECT_JEU.centerx, state.RECT_JEU.centery-int(155*sc)))
            state.screen.blit(title_sh, tr.move(4, 4)); state.screen.blit(title2, tr)
            dessiner_bouton_verre(state.screen, state.bouton_reprendre_pause, "REPRENDRE", state.font_big)
            if not state.intro_active:
                dessiner_bouton_verre(state.screen, state.bouton_recommencer_pause, "RECOMMENCER", state.font_big)
            dessiner_bouton_verre(state.screen, state.bouton_menu_principal_pause, "MENU PRINCIPAL", state.font_big, ACCENT_CYAN)
            dessiner_bouton_verre(state.screen, state.bouton_quitter_pause, "QUITTER", state.font_big, RED_DANGER)

        if state.start_menu_active:
            dessiner_menu_principal(state.screen)
        if state.credits_active:
            dessiner_ecran_credits(state.screen, state.pseudo)
        if state.input_active:
            ov6 = pygame.Surface((state.WIDTH,state.HEIGHT),pygame.SRCALPHA); ov6.fill((18,30,70,220))
            state.screen.blit(ov6,(0,0))
            t7 = state.font_gameover.render("VOTRE PSEUDO",True,ACCENT)
            t7_sh = state.font_gameover.render("VOTRE PSEUDO",True,SPACE_1)
            t7_r = t7.get_rect(center=(state.WIDTH//2,state.HEIGHT//2-int(130*sc)))
            state.screen.blit(t7_sh, t7_r.move(4, 4)); state.screen.blit(t7, t7_r)
            ir = pygame.Rect(0,0,int(320*sc),int(55*sc)); ir.center=(state.WIDTH//2,state.HEIGHT//2-int(50*sc))
            dessiner_cadre_pixel(state.screen, ir, border_color=ACCENT_CYAN)
            tp2 = state.font_big.render(state.pseudo+"_",True,TEXT_MAIN)
            state.screen.blit(tp2,tp2.get_rect(center=ir.center))
            dessiner_bouton_verre(state.screen,state.bouton_start,"LANCER LA MISSION",state.font_big,disabled=state.pseudo=="")

        # Horloge en jeu
        if not state.start_menu_active:
            now2 = datetime.datetime.now()
            dt_s2 = now2.strftime("%H:%M")
            dt_surf2 = state.font.render(dt_s2, True, TERM_GREEN_DIM)
            state.screen.blit(dt_surf2,(state.WIDTH-dt_surf2.get_width()-10, state.HEIGHT-dt_surf2.get_height()-8))

        pygame.display.flip()
        state.clock.tick(60)

        # ── Yield obligatoire pour pygbag (sinon le navigateur freeze) ──────────
        await asyncio.sleep(0)

    pygame.quit()


# ── Lancement ──────────────────────────────────────────────────────────────────
# asyncio.run() fonctionne aussi bien en local (CPython) qu'en web (pygbag/Pyodide).
asyncio.run(main())
