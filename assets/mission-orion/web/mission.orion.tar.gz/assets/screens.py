"""
screens.py — Écrans complets : intro cinématique, garage, menus, crédits.
"""

import math
import random
import datetime
import pygame

import state
from config import (
    NOM_DEVELOPPEUR, ANNEE_JEU,
    ACCENT, ACCENT_CYAN, ACCENT_MAGENTA, ACCENT_ORANGE,
    PANEL_BORDER, SPACE_1,
    TEXT_MAIN, TEXT_MUTED, TEXT_SOFT,
)
from drawing import (
    draw_text_simple, dessiner_bouton_verre,
    dessiner_orion_procedurale, dessiner_cadre_pixel,
)
from procedural import get_fond_procedural
from utils import dessiner_mecanicien


# ── Histoire d'intro (textes uniquement, séparé du dessin pour lisibilité) ───

INTRO_SCENES = [
    # Scène 0 — Sur Mars : ouverture, O.R.I.O.N. est déjà là, c'est un pote
    {
        'eyebrow': "// JOURNAL DE BORD — JOUR 242",
        'title':   "POUSSIÈRE ROUGE",
        'lines': [
            ("Mars. Encore Mars.", TEXT_MAIN),
            ("Quarante-deux mois que je vois la même", TEXT_MAIN),
            ("poussière rouge à travers le même hublot.", TEXT_MAIN),
            ("", None),
            ("O.R.I.O.N. :", ACCENT_CYAN),
            ("Capitaine, j'ai recompté : c'est la", TEXT_MAIN),
            ("987ème fois que vous soupirez aujourd'hui.", TEXT_MAIN),
            ("Vous battez votre record.", TEXT_MAIN),
            ("", None),
            ("— Toujours là pour me remonter le moral,", TEXT_MUTED),
            ("toi.", TEXT_MUTED),
        ],
    },
    # Scène 1 — L'Artefact à bord
    {
        'eyebrow': "// MISSION ACCOMPLIE",
        'title':   "L'ARTEFACT EST À BORD",
        'lines': [
            ("On l'a fait. Après tout ce temps.", TEXT_MAIN),
            ("Il est là, posé sur la console.", TEXT_MAIN),
            ("Plus chaud qu'un coeur, plus vieux", TEXT_MAIN),
            ("que la Terre, peut-être.", TEXT_MAIN),
            ("", None),
            ("O.R.I.O.N. :", ACCENT_CYAN),
            ("Joli caillou. Si vous l'aimez tant,", TEXT_MAIN),
            ("je peux vous laisser seuls dix minutes.", TEXT_MAIN),
            ("", None),
            ("Cap sur la Terre.", ACCENT),
        ],
    },
    # Scène 2 — Le réveil
    {
        'eyebrow': "// ANOMALIE DÉTECTÉE",
        'title':   "QUELQUE CHOSE A RÉPONDU",
        'lines': [
            ("Dès que nous avons franchi l'orbite", TEXT_MAIN),
            ("de Mars, l'Artefact s'est mis à émettre.", TEXT_MAIN),
            ("", None),
            ("Une seule note, répétée, calme.", TEXT_MAIN),
            ("Puis, depuis le vide, une réponse.", TEXT_MAIN),
            ("", None),
            ("O.R.I.O.N. :", ACCENT_CYAN),
            ("Bonne nouvelle : on n'est plus seuls.", TEXT_MAIN),
            ("Mauvaise nouvelle : on n'est plus seuls.", ACCENT_MAGENTA),
        ],
    },
    # Scène 3 — Les Gardiens
    {
        'eyebrow': "// SIGNATURE HOSTILE",
        'title':   "LES GARDIENS",
        'lines': [
            ("L'Artefact appartenait à quelqu'un.", TEXT_MAIN),
            ("Et ce quelqu'un envoie ses chiens.", TEXT_MAIN),
            ("", None),
            ("Des chasseurs aliens. Des essaims.", TEXT_MAIN),
            ("Des choses qui ne dorment jamais.", TEXT_MAIN),
            ("", None),
            ("O.R.I.O.N. :", ACCENT_CYAN),
            ("Comptage des hostiles en cours…", TEXT_MAIN),
            ("J'arrête à un million. Ça vous va ?", TEXT_MAIN),
        ],
    },
    # Scène 4 — Le plan
    {
        'eyebrow': "// PLAN DE VOL",
        'title':   "DROIT VERS LA TERRE",
        'lines': [
            ("Six secteurs nous séparent de la maison.", TEXT_MAIN),
            ("Astéroïdes, élites, armada complète,", TEXT_MAIN),
            ("et probablement leur Commandant.", TEXT_MAIN),
            ("", None),
            ("Une station de relais sur la route :", TEXT_MUTED),
            ("MECANO-7 nous y attend pour bricoler", TEXT_MUTED),
            ("ce qu'il reste du vaisseau.", TEXT_MUTED),
            ("", None),
            ("On ne s'arrête plus avant la Terre.", ACCENT),
        ],
    },
    # Scène 5 — Promesse
    {
        'eyebrow': "// MESSAGE PERSONNEL",
        'title':   "ELLE M'ATTEND",
        'lines': [
            ("Quelque part, là-bas, sur cette", TEXT_MAIN),
            ("petite bille bleue, elle m'attend.", TEXT_MAIN),
            ("", None),
            ("Je lui ai promis de revenir.", TEXT_MAIN),
            ("Aucun alien ne me fera mentir.", TEXT_MAIN),
            ("", None),
            ("O.R.I.O.N. :", ACCENT_CYAN),
            ("Boucliers en ligne. Laser chargé.", TEXT_MAIN),
            ("Et moi, toujours là. On y va, mon ami.", ACCENT),
        ],
    },
]


# ── Helpers intro ─────────────────────────────────────────────────────────────

_intro_stars = None


def _build_intro_stars(jw, jh):
    global _intro_stars
    rng = random.Random(42)
    stars = []
    for _ in range(220):
        x = rng.randint(0, jw-1); y = rng.randint(0, jh-1)
        br  = rng.randint(60, 255)
        sz  = rng.choice([1, 1, 1, 2, 2, 3])
        ts  = rng.uniform(0.001, 0.004)
        tof = rng.uniform(0, math.pi*2)
        ct  = rng.randint(0, 4)
        if ct == 0:   base_col = (br, br, min(255, br+40))
        elif ct == 1: base_col = (min(255,br+20), min(255,br+20), br)
        else:         base_col = (br, br, br)
        stars.append({'x':x,'y':y,'brightness':br,'size':sz,
                      'twinkle_speed':ts,'twinkle_offset':tof,'base_col':base_col})
    _intro_stars = stars


def _draw_intro_stars(surface, jx, jy, jw, jh, t):
    global _intro_stars
    if _intro_stars is None:
        _build_intro_stars(jw, jh)
    for star in _intro_stars:
        twinkle = 0.6 + 0.4*math.sin(t*star['twinkle_speed'] + star['twinkle_offset'])
        col = tuple(max(0, min(255, int(c*twinkle))) for c in star['base_col'])
        sx = jx + star['x']; sy = jy + star['y']
        if star['size'] == 1:
            surface.set_at((sx, sy), col)
        elif star['size'] == 2:
            pygame.draw.circle(surface, col, (sx, sy), 1)
        else:
            pygame.draw.circle(surface, col, (sx, sy), 2)
            halo = pygame.Surface((8, 8), pygame.SRCALPHA)
            pygame.draw.circle(halo, (*col, int(60*twinkle)), (4, 4), 3)
            surface.blit(halo, (sx-4, sy-4))


# ── Cinématique d'intro ────────────────────────────────────────────────────────

def dessiner_intro_cinematique(surface, scene):
    """Affiche une scène d'intro. Style portfolio : fond étoilé sobre,
       cadre central pixel avec eyebrow + titre + lignes de texte.
       Pas d'effets lumineux."""
    t   = pygame.time.get_ticks()
    sc2 = min(state.WIDTH/1600, state.HEIGHT/900)
    jx, jy = state.RECT_JEU.x, state.RECT_JEU.y
    jw, jh = state.RECT_JEU.width, state.RECT_JEU.height
    jcx = state.RECT_JEU.centerx

    # Fond simple : couleur unie + étoiles statiques
    surface.fill(SPACE_1, state.RECT_JEU)
    _draw_intro_stars(surface, jx, jy, jw, jh, t)

    if scene >= len(INTRO_SCENES):
        return
    data = INTRO_SCENES[scene]

    # Cadre central style "section__panel"
    panel_w = int(jw * 0.78)
    panel_h = int(jh * 0.72)
    panel = pygame.Rect(jx + (jw - panel_w) // 2, jy + int(jh * 0.10), panel_w, panel_h)
    dessiner_cadre_pixel(surface, panel, border_color=PANEL_BORDER)

    # Eyebrow (// SECTION)
    eb = state.font_item.render(data['eyebrow'], True, ACCENT_CYAN)
    surface.blit(eb, (panel.x + 20, panel.y + 14))

    # Trait pointillé sous le titre
    sep_y = panel.y + 18 + eb.get_height() + int(jh * 0.085)
    for dx in range(panel.x + 20, panel.right - 20, 8):
        pygame.draw.line(surface, PANEL_BORDER, (dx, sep_y), (dx + 4, sep_y), 1)

    # Titre principal — police pixel avec ombre dure
    title_s = state.font_big.render(data['title'], True, ACCENT)
    title_shadow = state.font_big.render(data['title'], True, SPACE_1)
    title_rect = title_s.get_rect(topleft=(panel.x + 20, panel.y + 18 + eb.get_height()))
    surface.blit(title_shadow, title_rect.move(3, 3))
    surface.blit(title_s, title_rect)

    # Lignes de récit
    y = sep_y + 14
    for line, color in data['lines']:
        if line and color is not None:
            ts = state.font_lore.render(line, True, color)
            surface.blit(ts, (panel.x + 24, y))
            y += state.font_lore.get_linesize() + 2
        else:
            y += state.font_lore.get_linesize() // 2

    # Indicateur "cliquer pour continuer" (sauf dernière scène déjà explicite)
    if (t // 600) % 2 == 0 and scene < len(INTRO_SCENES) - 1:
        ct = state.font_item.render("[ Cliquer pour continuer ]", True, TEXT_SOFT)
        surface.blit(ct, ct.get_rect(centerx=jcx, y=jy + jh - int(38 * sc2)))


# ── Popups (bloquants, utilisés lors des transitions) ─────────────────────────

def dessiner_popup_assistant(surface, message):
    """Gros popup centré (transitions de niveau) — style cadre pixel."""
    pw = int(state.WIDTH*0.55); ph = int(state.HEIGHT*0.24)
    rect = pygame.Rect((state.WIDTH-pw)//2, int(state.HEIGHT*0.16), pw, ph)
    dessiner_cadre_pixel(surface, rect, border_color=ACCENT_CYAN)

    # Label en chip type "// O.R.I.O.N."
    chip_w = state.font_item.size("// O.R.I.O.N.")[0] + 16
    chip = pygame.Rect(rect.x + 12, rect.y - state.font_item.get_linesize() // 2,
                       chip_w, state.font_item.get_linesize() + 6)
    pygame.draw.rect(surface, ACCENT_CYAN, chip)
    chip_t = state.font_item.render("// O.R.I.O.N.", True, SPACE_1)
    surface.blit(chip_t, (chip.x + 8, chip.y + 2))

    # Avatar
    ox = rect.x + int(pw*0.13); oy = rect.centery + int(ph*0.05)
    dessiner_orion_procedurale(surface, ox, oy, 1.3)

    # Texte (lecture VT323)
    ta = pygame.Rect(rect.x+int(pw*0.28), rect.y+14, int(pw*0.68), ph-50)
    draw_text_simple(surface, message, TEXT_MAIN, ta.x, ta.y, state.font_big)
    skip = state.font_item.render("Cliquer pour continuer", True, TEXT_SOFT)
    surface.blit(skip, (rect.centerx-skip.get_width()//2, rect.bottom-26))


def dessiner_popup_mecanicien(surface, message):
    pw = int(state.WIDTH*0.55); ph = int(state.HEIGHT*0.28)
    rect = pygame.Rect((state.WIDTH-pw)//2, int(state.HEIGHT*0.14), pw, ph)
    dessiner_cadre_pixel(surface, rect, border_color=ACCENT_ORANGE)

    chip_w = state.font_item.size("// MECANO-7")[0] + 16
    chip = pygame.Rect(rect.x + 12, rect.y - state.font_item.get_linesize() // 2,
                       chip_w, state.font_item.get_linesize() + 6)
    pygame.draw.rect(surface, ACCENT_ORANGE, chip)
    chip_t = state.font_item.render("// MECANO-7", True, SPACE_1)
    surface.blit(chip_t, (chip.x + 8, chip.y + 2))

    title_t = state.font_bold.render("GARAGE SPATIAL", True, ACCENT_ORANGE)
    surface.blit(title_t, title_t.get_rect(centerx=rect.centerx, y=rect.y+8))

    ox = rect.x + int(pw*0.12); oy = rect.y + int(ph*0.68)
    dessiner_mecanicien(surface, ox, oy, 1.4)
    ta = pygame.Rect(rect.x+int(pw*0.24), rect.y+int(ph*0.30), int(pw*0.74), ph-int(ph*0.40))
    draw_text_simple(surface, message, TEXT_MAIN, ta.x, ta.y, state.font_big)
    skip = state.font_item.render("[ Cliquer pour continuer ]", True, TEXT_SOFT)
    surface.blit(skip, (rect.centerx-skip.get_width()//2, rect.bottom-26))


# ── Garage ────────────────────────────────────────────────────────────────────

def dessiner_garage(surface):
    sc = min(state.WIDTH/1600, state.HEIGHT/900)
    ov = pygame.Surface((state.WIDTH, state.HEIGHT), pygame.SRCALPHA)
    ov.fill((*SPACE_1, 180)); surface.blit(ov, (0, 0))

    eb = state.font_item.render("// STATION RELAIS", True, ACCENT_CYAN)
    surface.blit(eb, eb.get_rect(center=(state.WIDTH//2, int(state.HEIGHT*0.06))))

    t2 = state.font_alert.render("GARAGE SPATIAL", True, ACCENT)
    t_sh = state.font_alert.render("GARAGE SPATIAL", True, SPACE_1)
    t_rect = t2.get_rect(center=(state.WIDTH//2, int(state.HEIGHT*0.12)))
    surface.blit(t_sh, t_rect.move(4, 4)); surface.blit(t2, t_rect)

    if len(state.garage_choices_made) == 0:
        st3 = state.font_big.render("Choisissez UNE amélioration — augmente les limites !", True, TEXT_MAIN)
    else:
        st3 = state.font_big.render("AMÉLIORATION INSTALLÉE — Prêt au décollage !", True, ACCENT)
    surface.blit(st3, st3.get_rect(center=(state.WIDTH//2, int(state.HEIGHT*0.22))))

    bw3 = int(state.WIDTH*0.2); bh3 = int(state.HEIGHT*0.42); sp3 = int(state.WIDTH*0.04)
    sx = (state.WIDTH - (bw3*3+sp3*2)) // 2; by3 = int(state.HEIGHT*0.27)

    state.bouton_garage_vie      = pygame.Rect(sx,              by3, bw3, bh3)
    state.bouton_garage_bouclier = pygame.Rect(sx+bw3+sp3,      by3, bw3, bh3)
    state.bouton_garage_tir      = pygame.Rect(sx+(bw3+sp3)*2,  by3, bw3, bh3)

    items_garage = [
        (state.bouton_garage_vie,      state.vie_img,        "VIE +2",
         ["Récupère 2 points de vie.", f"Max augmenté : 5 → 7"], None, 0),
        (state.bouton_garage_bouclier, None,                 "BOUCLIER",
         ["Absorbe le premier choc","de chaque vague."], "shield", 1),
        (state.bouton_garage_tir,      state.bonus_laser_img,"LASER +1",
         [f"Max augmenté : 4 → 5","Min garanti : 2 faisceaux"], None, 2),
    ]

    one_chosen = len(state.garage_choices_made) > 0
    for btn, icon, title, lines, extra, idx in items_garage:
        est_choisi = idx in state.garage_choices_made
        est_grise  = one_chosen and not est_choisi
        col_btn    = ACCENT if est_choisi else (PANEL_BORDER if est_grise else ACCENT_CYAN)

        # Cadre style pixel (sans arrondi, avec ombre)
        dessiner_cadre_pixel(surface, btn, border_color=col_btn,
                             bg_alpha=160 if est_choisi else (120 if est_grise else 200))

        if est_choisi:
            ok = state.font_bold.render("INSTALLÉ", True, ACCENT)
            surface.blit(ok, ok.get_rect(center=(btn.centerx, btn.y+int(18*sc))))
        if est_grise:
            lock_s = pygame.Surface((btn.width, btn.height), pygame.SRCALPHA)
            lock_s.fill((0,0,0,80)); surface.blit(lock_s, btn.topleft)

        if icon:
            isz = int(50*sc); ic2 = pygame.transform.scale(icon, (isz, isz))
            if est_grise: ic2 = ic2.copy(); ic2.fill((40,40,40), special_flags=pygame.BLEND_RGB_MULT)
            surface.blit(ic2, (btn.centerx-isz//2, btn.y+int(38*sc)))
        elif extra == "shield" and state.bouclier_img:
            isz = int(50*sc); ic3 = pygame.transform.scale(state.bouclier_img, (isz, isz))
            if est_grise: ic3 = ic3.copy(); ic3.fill((40,40,40), special_flags=pygame.BLEND_RGB_MULT)
            surface.blit(ic3, (btn.centerx-isz//2, btn.y+int(38*sc)))
        elif extra == "shield":
            c_col = PANEL_BORDER if est_grise else ACCENT_CYAN
            pygame.draw.circle(surface, c_col, (btn.centerx, btn.y+int(65*sc)), int(25*sc), 4)

        t3 = state.font_big.render(title, True, TEXT_SOFT if est_grise else col_btn)
        surface.blit(t3, t3.get_rect(center=(btn.centerx, btn.centery-10)))
        for j, dl in enumerate(lines):
            line_col = TEXT_SOFT if est_grise else (ACCENT if est_choisi else TEXT_MAIN)
            dl2 = state.font.render(dl, True, line_col)
            surface.blit(dl2, dl2.get_rect(center=(btn.centerx, btn.centery+28+j*22)))

    pw = int(220*sc); ph = int(50*sc)
    state.bouton_garage_partir = pygame.Rect(state.WIDTH//2-pw//2, int(state.HEIGHT*0.78), pw, ph)
    col_decoller = ACCENT if one_chosen else PANEL_BORDER
    dessiner_bouton_verre(surface, state.bouton_garage_partir, "DÉCOLLER", state.font_big, col_decoller)

    if state.garage_mecano_phase:
        dessiner_popup_mecanicien(surface, state.garage_mecano_message)




# ── Crédits ───────────────────────────────────────────────────────────────────

def dessiner_ecran_credits(surface, pseudo_joueur):
    sc = min(state.WIDTH/1600, state.HEIGHT/900)
    # Fond étoilé sobre
    surface.blit(get_fond_procedural(0, state.WIDTH, state.HEIGHT), (0, 0))
    ov = pygame.Surface((state.WIDTH, state.HEIGHT), pygame.SRCALPHA); ov.fill((*SPACE_1, 200))
    surface.blit(ov, (0, 0))

    # Cadre central
    pw = int(state.WIDTH * 0.74); ph = int(state.HEIGHT * 0.80)
    panel = pygame.Rect((state.WIDTH - pw) // 2, (state.HEIGHT - ph) // 2, pw, ph)
    dessiner_cadre_pixel(surface, panel, border_color=ACCENT)

    # Eyebrow
    eb = state.font_item.render("// MISSION ACCOMPLIE", True, ACCENT_CYAN)
    surface.blit(eb, (panel.x + 24, panel.y + 18))

    # Titre principal avec ombre dure
    titre = "RETOUR À LA MAISON"
    t_s = state.font_gameover.render(titre, True, ACCENT)
    t_sh = state.font_gameover.render(titre, True, SPACE_1)
    t_rect = t_s.get_rect(centerx=panel.centerx, y=panel.y + 50)
    surface.blit(t_sh, t_rect.move(4, 4))
    surface.blit(t_s, t_rect)

    # Phrase héros
    st4 = state.font_big.render(
        f"Capitaine {pseudo_joueur}, vous l'avez fait.",
        True, TEXT_MAIN)
    surface.blit(st4, st4.get_rect(centerx=panel.centerx, y=t_rect.bottom + 14))

    # Séparateur pointillé
    sep_y = t_rect.bottom + 14 + st4.get_height() + 22
    for dx in range(panel.x + 60, panel.right - 60, 8):
        pygame.draw.line(surface, PANEL_BORDER, (dx, sep_y), (dx + 4, sep_y), 1)

    # Bloc texte (récit final + dédicace)
    cy = sep_y + 18
    blocs = [
        ("La Terre est en vue.", state.font_lore, TEXT_MAIN),
        ("L'Artefact, lui, reste silencieux.", state.font_lore, TEXT_MAIN),
        ("Pour la première fois depuis Mars.", state.font_lore, TEXT_MAIN),
        ("", state.font_lore, TEXT_MAIN),
        ("// CRÉDITS", state.font_item, ACCENT_CYAN),
        (f"MISSION ORION  ·  {ANNEE_JEU}", state.font_bold, ACCENT),
        (f"Premier jeu indépendant de {NOM_DEVELOPPEUR}", state.font_lore, TEXT_MUTED),
        ("Développé en Python avec pygame.", state.font_lore, TEXT_MUTED),
        ("", state.font_lore, TEXT_MAIN),
        ("// DÉDICACE", state.font_item, ACCENT_MAGENTA),
        ("À ma femme,", state.font_bold, ACCENT),
        ("qui a soufflé cette histoire,", state.font_lore, TEXT_MAIN),
        ("qui m'a porté jour après jour par son", state.font_lore, TEXT_MAIN),
        ("investissement et sa bonne humeur.", state.font_lore, TEXT_MAIN),
        ("Ce jeu existe grâce à toi. Merci.", state.font_lore, ACCENT),
    ]
    for txt, fnt, col in blocs:
        if txt:
            ts2 = fnt.render(txt, True, col)
            surface.blit(ts2, ts2.get_rect(centerx=panel.centerx, y=cy))
        cy += fnt.get_linesize() + 2

    skip = state.font_item.render("[ CLIQUEZ ou ESPACE pour retourner au menu ]", True, TEXT_SOFT)
    surface.blit(skip, skip.get_rect(centerx=panel.centerx, y=panel.bottom - 32))


# ── Menu principal ────────────────────────────────────────────────────────────

def dessiner_menu_principal(surface):
    # Fond étoilé sobre + voile sombre
    surface.blit(get_fond_procedural(0, state.WIDTH, state.HEIGHT), (0, 0))
    ov = pygame.Surface((state.WIDTH, state.HEIGHT), pygame.SRCALPHA); ov.fill((*SPACE_1, 180))
    surface.blit(ov, (0, 0))

    t_top = int(state.HEIGHT * 0.16)

    # Eyebrow
    eb = state.font_item.render("// JEU COMMENCÉ POUR UN TP PYTHON, POURSUIVI POUR S'AMUSER", True, ACCENT_CYAN)
    surface.blit(eb, eb.get_rect(center=(state.WIDTH // 2, t_top)))

    # Titre principal avec ombre dure
    title = "MISSION ORION"
    t_s = state.font_alert.render(title, True, ACCENT)
    t_sh = state.font_alert.render(title, True, SPACE_1)
    t_rect = t_s.get_rect(center=(state.WIDTH // 2, t_top + state.font_alert.get_linesize()))
    surface.blit(t_sh, t_rect.move(5, 5))
    surface.blit(t_s, t_rect)

    sub = state.font_lore.render("RETOUR À LA MAISON", True, TEXT_MAIN)
    surface.blit(sub, sub.get_rect(center=(state.WIDTH // 2, t_rect.bottom + 16)))

    ver = state.font_item.render(f"{NOM_DEVELOPPEUR}  ·  {ANNEE_JEU}", True, TEXT_SOFT)
    surface.blit(ver, ver.get_rect(center=(state.WIDTH // 2, sub.get_rect().bottom + t_rect.bottom + 24)))

    dessiner_bouton_verre(surface, state.bouton_menu_histoire, "JOUER",   state.font_big)
    dessiner_bouton_verre(surface, state.bouton_menu_quitter,  "QUITTER", state.font_big)

    # Horloge
    now = datetime.datetime.now()
    dt_str = now.strftime("%H:%M:%S   %d/%m/%Y")
    dt_surf = state.font_item.render(dt_str, True, TEXT_SOFT)
    surface.blit(dt_surf, (state.WIDTH - dt_surf.get_width() - 12, state.HEIGHT - dt_surf.get_height() - 10))
