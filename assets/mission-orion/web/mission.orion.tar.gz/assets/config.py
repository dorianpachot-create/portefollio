"""
config.py — Constantes, couleurs et données de jeu (Mission Orion)
Aucune dépendance vers les autres modules du projet.

Palette et polices harmonisées avec le portfolio "Gradient" (Pixelify Sans + VT323).
"""

import os

# ── Identité ─────────────────────────────────────────────────────────────────
NOM_DEVELOPPEUR = "Dorian Pachot"
ANNEE_JEU       = "2026"

# ── Chemins ───────────────────────────────────────────────────────────────────

_ici    = os.path.dirname(os.path.abspath(__file__))
_parent = os.path.dirname(_ici)
SCRIPT_DIR = _parent if os.path.exists(os.path.join(_parent, "vaisseau.png")) else _ici

def _p(name): return os.path.join(SCRIPT_DIR, name)

CHEMIN_IMAGE      = _p("vaisseau.png")
CHEMIN_BALLE      = _p("balle.png")
CHEMIN_VIE        = _p("vie.png")
CHEMIN_BONUS      = _p("bonus.png")
CHEMIN_ETAGERE    = _p("etagere.png")
CHEMIN_BOUCLIER   = _p("bouclier.png")
CHEMIN_ALIEN1     = _p("alien1.png")
CHEMIN_ALIEN2     = _p("alien2.png")
CHEMIN_ALIEN3     = _p("alien3.png")
CHEMIN_ASTEROIDE  = _p("asteroide.png")
CHEMIN_BOSS       = _p("boss.png")
CHEMIN_MUSIQUE    = _p("musique_fond.mp3")
CHEMIN_SON_TIR    = _p("son_tir.wav")
CHEMIN_SON_EXPLO  = _p("son_explosion.wav")
CHEMIN_SON_DEGAT  = _p("son_degat.wav")
CHEMIN_SON_BONUS  = _p("son_bonus.wav")
FICHIER_PROG      = _p("progression.txt")

# ── Polices (TTF locaux pour harmoniser avec le portfolio web) ────────────────
_FONTS_DIR        = os.path.join(SCRIPT_DIR, "fonts")
CHEMIN_FONT_PIXEL_REG  = os.path.join(_FONTS_DIR, "PixelifySans-Regular.ttf")
CHEMIN_FONT_PIXEL_BOLD = os.path.join(_FONTS_DIR, "PixelifySans-Bold.ttf")
CHEMIN_FONT_READABLE   = os.path.join(_FONTS_DIR, "VT323.ttf")

# ── Palette (alignée portfolio "Gradient") ───────────────────────────────────
# Fonds spatiaux
SPACE_1           = (7, 9, 28)        # bleu nuit profond
SPACE_2           = (17, 22, 74)      # bleu marine spatial
SPACE_3           = (31, 19, 64)      # mauve nébuleuse

# Texte
TEXT_MAIN         = (240, 238, 255)   # presque blanc
TEXT_MUTED        = (185, 182, 214)
TEXT_SOFT         = (138, 135, 168)

# Accents arcade
ACCENT            = (255, 230, 109)   # jaune doré principal
ACCENT_CYAN       = (93, 204, 252)
ACCENT_MAGENTA    = (255, 110, 199)
ACCENT_ORANGE     = (255, 140, 66)

# Panneaux (cadres de menu façon portfolio)
PANEL_BG          = SPACE_1            # appliqué avec alpha PANEL_BG_ALPHA
PANEL_BG_ALPHA    = 200
PANEL_BORDER      = (74, 74, 122)
SHADOW_OFFSET     = 4                  # ombre dure sans flou

# Couleurs gameplay
BLACK             = (0, 0, 0)
WHITE             = TEXT_MAIN
SILVER            = TEXT_MUTED
RED_DANGER        = (255, 100, 110)
RED_DARK          = (80, 0, 0)
GREEN_OK          = (130, 235, 130)
GREY_ROCK         = (110, 110, 140)
ORANGE_EXPLOSION  = ACCENT_ORANGE
LASER_COLOR       = ACCENT_CYAN

# Robot O.R.I.O.N. (dessin procédural)
ROBOT_GREY        = (100, 110, 160)
ROBOT_DETAIL      = (60, 70, 120)

# Alias rétro-compat (encore référencés par certains modules)
SELECTED_BORDER   = ACCENT
PURPLE_BOSS       = ACCENT_MAGENTA
GLOW_ENEMY_COLOR  = ACCENT_CYAN
TERM_GREEN        = ACCENT_CYAN
TERM_GREEN_BRIGHT = TEXT_MAIN
TERM_GREEN_DIM    = TEXT_SOFT
TERM_GREEN_TEXT   = TEXT_MUTED
BRONZE            = ACCENT_ORANGE
YELLOW_GOLD       = ACCENT
CYAN_LASER        = ACCENT_CYAN

# ── Assistant ─────────────────────────────────────────────────────────────────
ASSISTANT_EYE_COLORS = [ACCENT_CYAN]

# ── Gameplay ──────────────────────────────────────────────────────────────────
SHOOT_DELAY          = 120
BULLET_SPEED         = 10
ALIEN_BASE_SPEED     = 3
ASTEROIDE_BASE_SPEED = 5
BONUS_FALL_SPEED     = 3
INTRO_TOTAL_SCENES   = 6

# Taille de la fenêtre — 4:3 pour s'intégrer dans le cadre arcade du portfolio
TAILLE_FENETRE_DEFAULT = (960, 720)

# ── Popups assistant ──────────────────────────────────────────────────────────
POPUP_DUREE_MS         = 3200
POPUP_IDLE_MIN_MS      = 7000   # délai min entre deux popups "ambiance"
POPUP_IDLE_MAX_MS      = 13000

# ── Niveaux (sans mode survie après le boss) ──────────────────────────────────
NIVEAUX = [
    {'id':0,'nom':'VAGUE 1 : EXTRACTION',
     'score_requis':0,'fond_style':0,
     'spawn_delay':60,'type_ennemi':'alien','alien_type':'alien1','vitesse_bonus':0,
     'message_entree':"Première vague détectée !\nScouts aliens en approche.",
     'message_jeu':"SCOUTS ALIENS !",'transition_duree':5500,'icone_carte':'alien1'},

    {'id':1,'nom':"VAGUE 2 : CHAMP D'ASTÉROÏDES",
     'score_requis':50,'fond_style':1,
     'spawn_delay':50,'type_ennemi':'asteroide','alien_type':None,'vitesse_bonus':1,
     'message_entree':"Champ d'astéroïdes droit devant !\nÉvitez les débris !",
     'message_jeu':"ATTENTION AUX IMPACTS !",'transition_duree':5500,'icone_carte':'asteroide'},

    {'id':2,'nom':'VAGUE 3 : ASSAUT ALIEN',
     'score_requis':300,'fond_style':2,
     'spawn_delay':45,'type_ennemi':'mixte','alien_type':'alien1','ratio_alien':0.6,'vitesse_bonus':2,
     'message_entree':"Ils ont appris !\nCombinant forces et obstacles.",
     'message_jeu':"MENACE MULTIPLE !",'transition_duree':6000,'icone_carte':'alien1'},

    {'id':3,'nom':'GARAGE SPATIAL',
     'score_requis':500,'fond_style':3,
     'spawn_delay':999,'type_ennemi':None,'alien_type':None,'vitesse_bonus':0,
     'message_entree':"Station relais détectée !\nTemps pour des améliorations.",
     'message_jeu':"Choisissez votre amélioration !",'transition_duree':4000,
     'icone_carte':'bonus','est_garage':True},

    {'id':4,'nom':"VAGUE 4 : CHASSEURS D'ÉLITE",
     'score_requis':500,'fond_style':4,
     'spawn_delay':40,'type_ennemi':'alien','alien_type':'alien2','vitesse_bonus':3,
     'message_entree':"Nouvelle menace identifiée !\nChasseurs d'élite aliens !",
     'message_jeu':"ÉLITE ENNEMIE !",'transition_duree':6000,'icone_carte':'alien2'},

    {'id':5,'nom':'VAGUE 5 : ARMADA COMPLÈTE',
     'score_requis':700,'fond_style':5,
     'spawn_delay':35,'type_ennemi':'armada','alien_type':'alien3','vitesse_bonus':4,
     'message_entree':"ALERTE MAXIMALE !\nToute l'armada est là !",
     'message_jeu':"ARMADA TOTALE !",'transition_duree':7000,'icone_carte':'alien3'},

    {'id':6,'nom':'VAGUE 6 : COMMANDANT SUPRÊME',
     'score_requis':700,'fond_style':6,
     'spawn_delay':999,'type_ennemi':'boss','alien_type':'boss','vitesse_bonus':0,
     'message_entree':"SIGNATURE MASSIVE DÉTECTÉE !\nLe Commandant Suprême arrive...",
     'message_jeu':"BOSS FINAL !",'transition_duree':9000,'icone_carte':'boss','est_boss':True},
]

# ── Phrases d'ambiance d'O.R.I.O.N. (rotation aléatoire) ─────────────────────
BLAGUES = [
    "Systèmes nominaux, Capitaine.",
    "Café virtuel : INDISPONIBLE.\nDommage.",
    "Je m'ennuie. Tirez sur quelque chose.",
    "Trajectoire optimale calculée\n(à 0,3% près).",
    "Bouclier opérationnel.\nMa fierté de robot aussi.",
    "Capitaine, vous tirez bien\npour un humain.",
    "Détection : aliens.\nDétection : agacement.",
    "Si on rate, je dirai\nque c'était un test.",
    "Réserve de carburant : suffisante.\nRéserve de patience : limite.",
    "Le vide spatial est si calme.\nNe le brisez pas.",
    "Conseil tactique : ne pas mourir.",
    "Mes circuits d'humour\nfonctionnent à 12 %. Désolé.",
    "Vos statistiques de survie\nme rassurent à peine.",
    "Belle esquive !\nJe note ça dans mon journal.",
    "Trois aliens viennent\nd'apprendre l'humilité.",
    "On rentre à la maison,\nun astéroïde à la fois.",
    "Détection d'objet brillant.\nNon, ce n'est pas une étoile.",
    "Question existentielle :\nun robot peut-il avoir le mal de l'espace ?",
    "Capitaine, vous respirez fort.\nC'est… inquiétant ?",
    "Vague suivante : bientôt.\nPrévoir un bouclier mental.",
]

MECANO_REPLIQUES = {
    0: [
        "J'ai soudé deux plaques de blindage\nsupplémentaires sur votre coque !\nVous pouvez encaisser 7 impacts désormais.",
        "Renforts structurels posés ! Ces gars-là\nfrappent fort, mais maintenant vous avez\n7 chances de vous en sortir. Bonne chance !"
    ],
    1: [
        "Bouclier Mk.IV installé ! Un vrai bijou.\nIl absorbera le premier impact de chaque\nvague. Essayez de ne pas le briser trop vite !",
        "Circuit de déflexion activé !\nCe bouclier vous sauvera la mise\nau moins une fois par vague. Soignez-le !"
    ],
    2: [
        "Canon auxiliaire brassé sur le stabilisateur !\nVous pouvez maintenir jusqu'à 5 faisceaux.\nEt jamais moins de 2, promis !",
        "Laser overclocké ! J'ai aussi bridé\nle régulateur pour que vous ne descendiez\njamais sous 2 faisceaux. C'est du solide !"
    ],
}
