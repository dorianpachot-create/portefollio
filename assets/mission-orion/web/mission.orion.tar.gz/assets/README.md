# Mission Orion — Structure du projet

## Architecture multi-fichiers

```
orion/
├── main.py         # Point d'entrée, boucle de jeu, événements, reset_game()
├── config.py       # Toutes les constantes : couleurs, niveaux, gameplay
├── state.py        # État global mutable (variables partagées entre modules)
├── procedural.py   # Génération procédurale des arrière-plans (cache intégré)
├── assets.py       # Chargement images/sons, redimensionnement, fontes
├── entities.py     # Classe Boss + fonctions particules (create_explosion…)
├── drawing.py      # Primitives UI : panneaux, boutons, cockpit, arsenal, carte
├── screens.py      # Écrans complets : intro, garage, menus, crédits, CV
└── utils.py        # Utilitaires : scores, progression, sons, helpers gameplay
```

## Dépendances entre modules

```
config.py      (pas d'import projet)
    ↑
state.py       (← config)
    ↑
procedural.py  (← config)
assets.py      (← state, config, procedural)
entities.py    (← state, config)
    ↑
drawing.py     (← state, config, assets, entities)
utils.py       (← state, config, assets)
    ↑
screens.py     (← state, config, drawing, procedural, utils, entities)
    ↑
main.py        (← tout)
```

## Lancement

```bash
python main.py
```

## Ajouter un nouveau niveau

Ouvrir `config.py` → modifier la liste `NIVEAUX`.  
Les fonds procéduraux se configurent via `fond_style` (0-7).

## Ajouter un skin laser / vaisseau

Ouvrir `config.py` → modifier `LASER_COULEURS`/`LASER_NOMS`  
ou `VAISSEAU_TEINTES`/`VAISSEAU_TEINTES_NOMS`/`VAISSEAU_TEINTES_COLS`.

## Modifier un comportement UI

- **Dessin réutilisable** (bouton, panneau, cockpit) → `drawing.py`
- **Écran complet** (menu, garage, crédits) → `screens.py`
- **Logique gameplay** (tir, collision, spawn) → `main.py`

## Modifier le Boss

Classe `Boss` dans `entities.py` :  
- `update()` : IA, orbite, attaques
- `draw()` : rendu
- `take_damage()` : phases 1/2/3
- Méthodes `_shoot_*()` : nouveaux patterns de tir
