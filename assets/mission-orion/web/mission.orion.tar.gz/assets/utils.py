"""
utils.py — Progression, sons, popups O.R.I.O.N., helpers gameplay et dessin du mécano.
"""

import math
import os
import random

import pygame

import state
from config import (
    FICHIER_PROG, NIVEAUX,
    POPUP_DUREE_MS, POPUP_IDLE_MIN_MS, POPUP_IDLE_MAX_MS, BLAGUES,
)


# ── Progression ───────────────────────────────────────────────────────────────

def sauver_progression():
    with open(FICHIER_PROG, "w") as f:
        f.write(f"histoire_complete:{1 if state.histoire_complete else 0}\n")


def lire_progression():
    state.histoire_complete = False
    if not os.path.exists(FICHIER_PROG):
        return
    with open(FICHIER_PROG, "r") as f:
        for line in f:
            line = line.strip()
            try:
                k, v = line.split(":")
                if k == "histoire_complete":
                    state.histoire_complete = int(v) == 1
            except Exception:
                pass


# ── Sons ──────────────────────────────────────────────────────────────────────

def jouer_son(son):
    if son and state.volume_sfx > 0:
        son.set_volume(state.volume_sfx)
        son.play()


# ── Popups assistant ──────────────────────────────────────────────────────────

def set_popup_assistant(msg, duree_ms=POPUP_DUREE_MS, priority=1):
    """Affiche un popup d'O.R.I.O.N. en bas à gauche.
       priority=1 → événement (écrase l'ambiance).
       priority=0 → phrase d'ambiance (n'écrase pas un événement en cours)."""
    now = pygame.time.get_ticks()
    if priority < state.popup_assistant_priority and now < state.popup_assistant_until:
        return
    state.popup_assistant_msg      = msg
    state.popup_assistant_until    = now + duree_ms
    state.popup_assistant_priority = priority
    # Décale la prochaine apparition d'ambiance pour ne pas spammer
    state.popup_assistant_next_ms  = now + duree_ms + random.randint(POPUP_IDLE_MIN_MS, POPUP_IDLE_MAX_MS)


def tick_popup_ambiance():
    """Lance une réplique d'ambiance si le délai est écoulé et qu'aucun popup n'est actif."""
    now = pygame.time.get_ticks()
    if now < state.popup_assistant_until:
        return
    if now < state.popup_assistant_next_ms:
        return
    set_popup_assistant(random.choice(BLAGUES), priority=0)


def planifier_premier_popup_ambiance():
    """Programme la première apparition d'ambiance après le démarrage / reset."""
    state.popup_assistant_next_ms = pygame.time.get_ticks() + random.randint(
        POPUP_IDLE_MIN_MS, POPUP_IDLE_MAX_MS
    )


# ── Helpers gameplay ──────────────────────────────────────────────────────────

def get_niveau_actuel():
    return NIVEAUX[min(state.niveau_courant_id, len(NIVEAUX) - 1)]


def verifier_avancement_niveau():
    if state.garage_actif or state.game_over or state.victoire \
       or state.en_pause or state.credits_active:
        return
    nxt = state.niveau_courant_id + 1
    if nxt < len(NIVEAUX) and state.compteur >= NIVEAUX[nxt]['score_requis']:
        state.niveau_courant_id = nxt


def get_alien_image(alien_type):
    img = state.aliens_images.get(alien_type) if alien_type else None
    if img is not None:
        return pygame.transform.scale(img, (state.alien_size, state.alien_size))
    return state.alien_img_defaut


def get_asteroide_image():
    if state.asteroide_img is not None:
        return pygame.transform.scale(
            state.asteroide_img, (state.asteroide_size, state.asteroide_size))
    return state.asteroide_img_defaut


def make_tinted_bullet(angle_deg):
    """Renvoie l'image de balle tournée à l'angle donné."""
    return pygame.transform.rotate(state.balle_img, angle_deg)


def get_player_img_tinted():
    """Renvoie l'image du vaisseau du joueur (réservée pour d'éventuels effets)."""
    return state.player_img


# ── Dessin MECANO-7 (utilisé dans le garage et son popup) ─────────────────────

def dessiner_mecanicien(surface, cx, cy, scale=1.0):
    t = pygame.time.get_ticks()
    bs = int(28 * scale)
    col_corps  = (70, 55, 40)
    col_casque = (200, 160, 20)
    col_oeil   = (255, 200, 50)
    col_outil  = (180, 190, 200)

    pygame.draw.circle(surface, col_corps, (cx, cy), bs)
    pygame.draw.circle(surface, (50, 40, 30), (cx, cy), bs, 2)
    pygame.draw.rect(surface, col_casque, (cx - bs, cy - bs, bs * 2, int(10 * scale)))
    pygame.draw.rect(surface, (230, 180, 30),
                     (cx - int(bs * 0.6), cy - bs - int(10 * scale),
                      int(bs * 1.2), int(12 * scale)), border_radius=3)
    pygame.draw.rect(surface, (30, 80, 40),
                     (cx - int(bs * 0.7), cy - bs + int(3 * scale),
                      int(bs * 1.4), int(7 * scale)), border_radius=2)

    eo = int(10 * scale); es = int(5 * scale)
    pygame.draw.circle(surface, col_oeil, (cx - eo, cy - int(4 * scale)), es)
    pygame.draw.circle(surface, col_oeil, (cx + eo, cy - int(4 * scale)), es)

    # Outil qui bouge légèrement
    ang = math.sin(t * 0.003) * 0.4
    wx  = cx + int(math.cos(ang) * bs * 1.3)
    wy  = cy + int(math.sin(ang) * bs * 0.5)
    pygame.draw.line(surface, col_outil, (cx + int(bs * 0.6), cy), (wx, wy), int(4 * scale))
    pygame.draw.circle(surface, col_outil, (wx, wy), int(5 * scale))
    pygame.draw.circle(surface, col_outil, (wx, wy), int(3 * scale), 1)
    pygame.draw.circle(surface, (255, 120, 20), (cx, cy + int(8 * scale)), int(4 * scale))
