"""
state.py — État global mutable du jeu (Mission Orion).
Tous les autres modules importent ce module et y lisent / écrivent.
"""

import pygame
from config import TAILLE_FENETRE_DEFAULT

# ── Pygame core ───────────────────────────────────────────────────────────────
screen = None   # initialisé dans main.py
clock  = None
WIDTH, HEIGHT = TAILLE_FENETRE_DEFAULT

# ── Zones d'affichage (calculées par assets.recalculer_zones) ─────────────────
RECT_JEU             = None
RECT_ARSENAL_AREA    = None
RECT_POPUP_ASSISTANT = None
center_jeu           = (0, 0)

# ── Fontes (chargées par assets.update_fonts) ─────────────────────────────────
font          = None     # VT323 — texte courant
font_item     = None     # VT323 — petit
font_lore     = None     # VT323 — récits
font_bold     = None     # Pixelify Bold — HUD / labels
font_big      = None     # Pixelify Bold — titres
font_gameover = None     # Pixelify Bold — game over / pause
font_huge     = None     # Pixelify Bold — countdown
font_alert    = None     # Pixelify Bold — titre menu

# ── Images (chargées par assets.charger_ressources / rescale_all_images) ──────
player_img           = None
alien_img_defaut     = None
balle_img            = None
vie_img              = None
vie_grise_img        = None
asteroide_img_defaut = None
bonus_img            = None
bonus_laser_img      = None
bouclier_img         = None
etagere_original     = None
current_etagere_img  = None
aliens_images        = {}    # {'alien1': Surface, ...}
asteroide_img        = None
boss_raw_img         = None

# ── Tailles (recalculées selon la résolution) ─────────────────────────────────
player_size    = 0
alien_size     = 0
bullet_size    = (0, 0)
vie_size       = 0
asteroide_size = 0
bonus_size     = 0

# ── Sons (chargés par assets.charger_ressources) ──────────────────────────────
son_tir       = None
son_explosion = None
son_degat     = None
son_bonus     = None

# ── Audio (volumes figés) ─────────────────────────────────────────────────────
volume_music = 0.5
volume_sfx   = 0.7

# ── Progression sauvegardée ───────────────────────────────────────────────────
histoire_complete = False

# ── Joueur ────────────────────────────────────────────────────────────────────
pseudo              = ""
vies                = 3
compteur            = 0
laser_level         = 1
last_shot_time      = 0
max_vies_actuel     = 5
max_laser_level     = 4
inventory           = []
selected_item_index = 0

# ── Entités ───────────────────────────────────────────────────────────────────
bullets       = []
enemies       = []
bonuses_drops = []
particles     = []
boss_actif    = None

# ── Timers / état de jeu ──────────────────────────────────────────────────────
spawn_timer      = 0
spawn_delay      = 60
hud_damage_timer = 0
halo_red_timer   = 0

# ── Popup assistant (apparition temporaire en bas à gauche) ───────────────────
popup_assistant_msg      = ""
popup_assistant_until    = 0   # timestamp ms de fin d'affichage
popup_assistant_next_ms  = 0   # prochaine fenêtre d'apparition d'ambiance
popup_assistant_priority = 0   # 0 = ambiance, 1 = événement (écrase l'ambiance)

# ── Flags d'écran ─────────────────────────────────────────────────────────────
game_over         = False
victoire          = False
en_pause          = False
running           = True
input_active      = False
start_menu_active = True
credits_active    = False

# ── Progression de niveau ─────────────────────────────────────────────────────
niveau_courant_id   = 0
niveau_precedent_id = -1

# ── Transitions / fade ────────────────────────────────────────────────────────
transition_active    = False
transition_start     = 0
transition_message   = ""
transition_duree_cur = 3000
countdown_active     = False
countdown_start_time = 0
fade_active          = False
fade_alpha           = 0

# ── Intro / tutoriel ──────────────────────────────────────────────────────────
intro_active = False
intro_state  = 0    # 0 = cinématique, 1 = tuto
intro_scene  = 0
tuto_step    = 0

# ── Gameplay spécial ──────────────────────────────────────────────────────────
bouclier_actif     = False
bouclier_permanent = False
bomb_anim_active   = False
bomb_radius        = 0
bomb_max_radius    = 1200
bomb_hit_boss      = False   # une bombe ne touche le boss qu'une seule fois

# ── Garage ────────────────────────────────────────────────────────────────────
garage_actif         = False
garage_choices_made  = set()
garage_intro_active  = False
garage_intro_phase   = 0
garage_intro_start   = 0
garage_mecano_phase  = False
garage_mecano_message = ""

# ── Rects de boutons (positions mises à jour par main.update_button_positions) ─
bouton_relancer             = pygame.Rect(0, 0, 200, 60)
bouton_start                = pygame.Rect(0, 0, 440, 60)
bouton_pause_icone          = pygame.Rect(0, 0,  40, 40)
bouton_reprendre_pause      = pygame.Rect(0, 0, 250, 50)
bouton_recommencer_pause    = pygame.Rect(0, 0, 250, 50)
bouton_quitter_pause        = pygame.Rect(0, 0, 250, 50)
bouton_menu_principal_pause = pygame.Rect(0, 0, 250, 50)
bouton_menu_histoire        = pygame.Rect(0, 0, 260, 55)
bouton_menu_quitter         = pygame.Rect(0, 0, 260, 55)
bouton_quitter_gameover     = pygame.Rect(0, 0, 200, 60)
bouton_garage_vie           = pygame.Rect(0, 0, 100, 100)
bouton_garage_bouclier      = pygame.Rect(0, 0, 100, 100)
bouton_garage_tir           = pygame.Rect(0, 0, 100, 100)
bouton_garage_partir        = pygame.Rect(0, 0, 100, 50)
